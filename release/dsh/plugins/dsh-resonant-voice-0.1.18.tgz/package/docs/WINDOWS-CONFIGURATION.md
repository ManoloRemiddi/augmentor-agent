<!-- Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT -->

# Windows private configuration

Candidate package 0.1.17 adds a Windows adapter for token and configuration
files. Augmentor's native Windows DSH setup exposed the previous Unix-only
permission check: it rejected Windows tokens regardless of their real ACLs.

The adapter uses Koffi 3.2.1 and the Windows kernel/security APIs, both native x64
and ARM64. Initialization creates protected user-plus-SYSTEM directories/files
with the user's explicit SID as owner. Reads inspect the opened file's owner,
ACL, type and link count before returning content. Reparse-point ancestors,
hard links, broader permissions and unrecognized ACL forms are refused; existing
files and their permissions are never silently rewritten. Initialization retries
preserve tokens and model/speech settings. Unix initialization and validation keep
their previous behavior. No Augmentor runtime import or sibling checkout is used.

The native checks exercise a Unicode path, restart/retry preservation, a real
Everyone read grant, hard links and junctions. The Windows CI workflow runs them
on both architectures. At `22fd869`, all four native configuration checks pass on Windows x64 and
ARM64 in [run 36360561703](https://github.com/ManoloRemiddi/resonant-voice/actions/runs/36360561703).
Linux passes 36 Node tests with two Windows-only skips. This is configuration qualification,
not microphone, ASR/TTS, GPU, latency or a complete Windows speech service claim.
The user's installed 0.1.16 companion and RTX 5090 placement are unchanged.

Implementation references: [Koffi output parameters](https://koffi.dev/output),
[CreateFileW](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew)
and [GetSecurityInfo](https://learn.microsoft.com/en-us/windows/win32/api/aclapi/nf-aclapi-getsecurityinfo).
