<!-- Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT -->
# Resonant Voice protocol 1

## 0.1.18 reversible maintenance admission

`GET /health` advertises `maintenanceAdmission: 1`. The existing authenticated
loopback HTTP bridge additionally accepts `POST /internal/maintenance` with an
exact `{method, params}` object. Methods are `host.maintenance.status`, `prepare`,
`renew`, `cancel`, and `commit`. Status takes `{}`; all other methods take exactly
`{token}` with 32–64 lowercase hex characters. Responses use the common
`augmentor-component-maintenance/1` envelope: `phase` (`ready`, `prepared`,
`closing`), `active`, and `expiresInSeconds`. This is an additive private contract;
the caller still needs the existing voice token. It confers no process ownership.

Preparation refuses open or authenticating WebSockets, unexpired tickets,
accepted HTTP work (including incomplete bodies and previews), active synthesis
and ASR workers still exiting after their UI disconnects. It neither cancels
recording/playback nor changes saved settings. While prepared, new ordinary HTTP
requests receive 409 and new WebSocket upgrades are refused. Existing work causes
preparation to fail; it is never interrupted to make preparation succeed.

A preparation expires after 30 monotonic seconds. Repeating prepare does not
renew it; explicit renew does. Cancel or expiry reopens admission. Commit is
irreversible, acknowledges before closing the idle listeners and permits natural
Node exit. It does not send process signals, terminate sockets with active work
or stop an external Breeze server. ASR closure uses stdin EOF and is tracked
until the actual child close event, preserving the worker's existing EOF handling.
Failure to settle keeps maintenance busy. Explicit voice Stop/owner cancellation
retains its existing behavior and is distinct from this idle maintenance path.

The companion owns only this component reservation. A product coordinator must
reserve every surface/harness and its process owner before committing, cancel
all reversible reservations on preparation failure, and separately establish
installation-file exclusivity. Only a service explicitly owned by that product
may be stopped. A matching speech protocol alone is not ownership evidence.

Local real HTTP/WebSocket tests cover admission, expiry, settings preservation,
pending ASR and synthesis, and a separate real CLI `beforeExit` proof. Speech and
ASR in the concurrency tests are deterministic fixtures. Native Windows x64/ARM64
execution and complete Augmentor coordination are pending; no installed speech
service, model placement or physical audio acceptance changed.

DSH `POST /api/resonant-voice` accepts `{surface: "linux" | "browser", sessionId}` with Augmentor's existing product token header. It rechecks the persisted session preset (`augmentor-<surface>-product`) and rejects subagents. It returns `{ok, protocol: "resonant-voice/1", sessionId, url, ticket}`. Only trusted Augmentor native code/native-host code sees the product token.

Connect to the returned loopback `/voice` WebSocket and send `{type:"auth",ticket}` within five seconds. Tickets expire after fifteen seconds and can be redeemed once. One voice connection owns capture/playback globally. After Breeze health and resident ASR initialization, `ready` advertises 16 kHz mono signed little-endian 16-bit input and 24 kHz equivalent output.

Controls are JSON: `begin`, `end`, `interrupt`, and `mute` with Boolean `value`. Input between begin/end is binary PCM without a WAV header, in chunks at most 65,536 bytes (20 ms / 640 bytes recommended). No audio is submitted as a user prompt until ASR emits a final nonempty transcript. The server allocates its UUID `requestId`; clients send that ID exactly once to their existing DSH prompt path. On an unknown submission result they show uncertainty and never automatically retry.

Server JSON events include `ready`, `clear {generation}`, `listening`, `recognizing`, `transcript {text, requestId, sessionId}`, `empty-transcript`, `speaking`, `speech-idle`, `timing`, and `error {message}`. A `clear` stops all scheduled/current playback before any later audio is accepted.

Output binary frames have an eight-byte prefix: unsigned 32-bit little-endian generation followed by unsigned 32-bit little-endian sequence, then signed 16-bit little-endian PCM. Clients discard generations other than the most recent `clear`, preserve WebSocket ordering, and limit queued playback to eight seconds. Timing event `first-pcm` means transport PCM availability, not audible onset or first substantive answer latency.

The private HTTP bridge requires `x-resonant-token`. `/internal/ticket` creates surface/session tickets; `/internal/event` transports session ID, stream ID and `user-turn`, `start`, `text`, `end` or `cancel`. DSH supplies text-delta events only; reasoning/tool payloads are excluded. `user-turn` follows DSH's user-inbox claim, so an old tool continuation cannot restart speech after microphone interruption. Text events are coalesced for 25 ms and ordered per session; bounded transport failure disables forwarding instead of blocking the agent loop.

ASR workers exchange bounded JSONL on private process pipes: `begin/audio/end` with utterance UUID; audio uses base64 only on that internal pipe. They retain a loaded model and at most one transcription job. TTS adapters expose `health()` and an abortable async iterable `speak(text, signal)` returning PCM buffers. The current HTTP adapter streams audio for completed text segments; it does not claim persistent incremental-text inference.


### 0.1.7 recording limit extension

`ready.maxUtteranceSeconds` advertises the configured limit (default and maximum 600). Configuration accepts integer limits from 1 to 600 seconds. The ASR worker receives the same limit through `--max-seconds`. New native clients conservatively assume 60 when talking to an older service without this field.

The service ends capture at either its PCM byte budget or wall-clock deadline, emits `recording-ended {reason:"limit",maxUtteranceSeconds}`, then `recognizing`, and transcribes the retained audio. Clients stop the input stream on `recording-ended`. In-flight PCM and duplicate `end` after automatic finish are ignored until the next `begin`; malformed PCM alignment remains an error. This is an additive protocol-1 change. Recordings remain ephemeral, and no automatic resend follows an unknown submission outcome.

### 0.1.13 delivery and hands-free additions

The terminal `resonant_voice_reply` tool accepts 1–8 model-authored `{text, speech}` passages (4000 total characters). `speech` has an emotion (`neutral`, `warm`, `sad`, `excited`, `playful`, `calm`), speedMultiplier (0.97–1.03, normally 1), and optional laughter (`none`, `before`, `after`). Legacy valid 0.85–1.15 hints are clamped to the smaller range. Tool result metadata preserves the same visible words; only the Breeze adapter adds vocal-event syntax. CFG is 2 for explicit laughter and 1 otherwise.

The private ordered bridge sends `turn-complete {requestId}` on DSH driver idle, after response events. The service validates the current session/request and forwards `turn-complete {generation, requestId}`. `speech-idle` alone does not establish a finished agent turn or drained audio hardware. The native client waits for matching terminal state, speech-idle and actual device drain before showing listening again. `playback-drained {generation}` is an optional client acknowledgment, not microphone authority. Newer controls/events are additive; manual clients can ignore the terminal event.

Native hands-free uses the same begin/PCM/end transport after local CPU VAD confirms speech. Its capture stream stays alive during the active conversation and is closed on Stop, Escape, session change or failure. Detection is suspended during ASR finalization; it resumes for speaking/steering after the transcript is submitted. A dedicated AEC route supplies both capture and playback without changing desktop defaults.

## Independent native-window voice profiles

The authenticated `/internal/preferences` and `/internal/preview` requests, and
WebSocket `auth`, accept optional `profile` (default `main`). Names match
`[a-z][a-z0-9-]{0,31}`. Native Augmentor sends its window instance name; older and
browser clients keep the main profile. This is an additive `resonant-voice/1`
contract extension.

Main preferences remain in `tts`. A named profile is copied from `tts` once and
stored under `voiceProfiles[name]` in the existing settings file. Saving one
profile preserves the others. Each user turn snapshots its owner's selected
voice, speed, volume and synthesis settings; structured delivery then adjusts
that snapshot. Microphone ownership remains exclusive across windows.

Verification on 19 September 2026: all 33 service tests passed, including persisted
clone-once profiles and HTTP/WebSocket selection through a fake TTS adapter. The
installed native dialog also saved/reloaded secondary settings against the live
companion without changing the primary; original secondary values were restored.
No new GPU or listening qualification is claimed by these settings tests.

## 0.1.16 incremental recognition

Recognition starts during capture, normally after each two seconds of new PCM.
`transcript-partial {text, requestId, sessionId}` is a revisable hypothesis for
progress only. Clients must never submit it, append it as a committed message or
persist it to memory. Only the existing final `transcript` is a submission.
Stale worker utterance IDs and disconnected owners are discarded as before.
Older clients safely ignore the new event and receive their usual final.

`timing` stage `asr-progress` carries numeric `passes`, `decodedThroughSeconds`
and `decodeMs`. Stage `asr-final` includes those fields and `elapsedMs` measured
from end-input receipt, including any outstanding decode. These values contain
no audio or text. First PCM timing still includes model and synthesis waits and
is not an acoustic onset measurement. See [incremental ASR](INCREMENTAL-ASR.md).
