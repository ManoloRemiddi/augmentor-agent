// Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT
// Private, reversible component admission. No process ownership is inferred.
import {performance} from 'node:perf_hooks';

export class MaintenanceBusy extends Error {}

export class Maintenance {
  constructor({busy=()=>false,clock=()=>performance.now()/1000,ttl=30}={}) {
    Object.assign(this,{busy,clock,ttl});this.active=0;this.token=null;this.expires=0;this.closing=false;
  }
  expire(){if(this.token&&!this.closing&&this.clock()>=this.expires){this.token=null;this.expires=0;}}
  status(){
    this.expire();
    return {protocol:'augmentor-component-maintenance/1',phase:this.closing?'closing':this.token?'prepared':'ready',
      active:this.active+(this.busy()?1:0),expiresInSeconds:this.token&&!this.closing?Math.max(0,this.expires-this.clock()):null};
  }
  enter(){
    this.expire();
    if(this.token||this.closing)throw new MaintenanceBusy('Voice maintenance is in progress. This request was not started.');
    this.active++;let done=false;
    return ()=>{if(!done){done=true;this.active--;}};
  }
  control(method,params){
    const action=typeof method==='string'&&method.startsWith('host.maintenance.')?method.slice(17):null;
    if(!['status','prepare','renew','cancel','commit'].includes(action)||!params||typeof params!=='object'||Array.isArray(params))throw Error('Unsupported maintenance request.');
    const keys=Object.keys(params);
    if(action==='status'){
      if(keys.length)throw Error('Maintenance status does not accept fields.');
      return this.status();
    }
    if(keys.length!==1||keys[0]!=='token'||typeof params.token!=='string'||!/^([a-f0-9]{32,64})$/.test(params.token))throw Error('A valid maintenance reservation is required.');
    this.expire();
    if(action==='prepare'){
      if(this.closing||this.active||this.busy()||this.token&&this.token!==params.token)throw new MaintenanceBusy('Voice has an open connection, pending work or another maintenance reservation. Its work was preserved.');
      if(!this.token){this.token=params.token;this.expires=this.clock()+this.ttl;}
    }else{
      if(this.token!==params.token)throw Error('The maintenance reservation expired or does not match. Prepare again.');
      if(action==='commit'){
        if(this.active||this.busy())throw new MaintenanceBusy('Voice is still draining accepted work.');
        this.closing=true;
      }else if(this.closing)throw Error('Shutdown is already committed.');
      else if(action==='renew')this.expires=this.clock()+this.ttl;
      else if(action==='cancel'){this.token=null;this.expires=0;}
    }
    return this.status();
  }
}
