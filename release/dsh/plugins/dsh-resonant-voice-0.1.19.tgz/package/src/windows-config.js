// Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT
// Native per-user configuration. Unix mode bits do not express Windows privacy.
// Keep identity/ACL checks on the opened file and reject links and broad ACLs.
import koffi from 'koffi';
import {dirname, resolve} from 'node:path';
import {randomUUID} from 'node:crypto';
import {unlinkSync} from 'node:fs';

const kernel = koffi.load('kernel32.dll'), security = koffi.load('advapi32.dll');
const api = (lib, name, result, args) => lib.func('__stdcall', name, result, args);
const close = api(kernel, 'CloseHandle', 'int', ['void *']);
const localFree = api(kernel, 'LocalFree', 'void *', ['void *']);
const lastError = api(kernel, 'GetLastError', 'uint32_t', []);
const currentProcess = api(kernel, 'GetCurrentProcess', 'void *', []);
const openToken = api(security, 'OpenProcessToken', 'int', ['void *', 'uint32_t', koffi.out(koffi.pointer('void *'))]);
const tokenInfo = api(security, 'GetTokenInformation', 'int', ['void *', 'int', koffi.out('void *'), 'uint32_t', koffi.out('uint32_t *')]);
const sidToString = api(security, 'ConvertSidToStringSidW', 'int', ['void *', koffi.out(koffi.pointer('void *'))]);
const fromSddl = api(security, 'ConvertStringSecurityDescriptorToSecurityDescriptorW', 'int', ['str16', 'uint32_t', koffi.out(koffi.pointer('void *')), 'void *']);
const getSecurity = api(security, 'GetSecurityInfo', 'uint32_t', ['void *', 'int', 'uint32_t',
  koffi.out(koffi.pointer('void *')), 'void *', koffi.out(koffi.pointer('void *')), 'void *', koffi.out(koffi.pointer('void *'))]);
const getControl = api(security, 'GetSecurityDescriptorControl', 'int', ['void *', koffi.out('uint16_t *'), koffi.out('uint32_t *')]);
const aclInfo = api(security, 'GetAclInformation', 'int', ['void *', koffi.out('void *'), 'uint32_t', 'int']);
const getAce = api(security, 'GetAce', 'int', ['void *', 'uint32_t', koffi.out(koffi.pointer('void *'))]);
const attributes = api(kernel, 'GetFileAttributesW', 'uint32_t', ['str16']);
const SA = koffi.struct({length: 'uint32_t', descriptor: 'void *', inherit: 'int'});
const createDirectory = api(kernel, 'CreateDirectoryW', 'int', ['str16', koffi.pointer(SA)]);
const createFile = api(kernel, 'CreateFileW', 'void *', ['str16', 'uint32_t', 'uint32_t', koffi.pointer(SA), 'uint32_t', 'uint32_t', 'void *']);
const fileInfo = api(kernel, 'GetFileInformationByHandle', 'int', ['void *', koffi.out('void *')]);
const readFile = api(kernel, 'ReadFile', 'int', ['void *', koffi.out('void *'), 'uint32_t', koffi.out('uint32_t *'), 'void *']);
const writeFile = api(kernel, 'WriteFile', 'int', ['void *', 'void *', 'uint32_t', koffi.out('uint32_t *'), 'void *']);
const flush = api(kernel, 'FlushFileBuffers', 'int', ['void *']);
const moveFile = api(kernel, 'MoveFileExW', 'int', ['str16', 'str16', 'uint32_t']);
const FULL = 0x1f01ff, REPARSE = 0x400, DIRECTORY = 0x10;

function failure(operation, code = lastError()) {
  return Error(`Private voice configuration: ${operation} failed (Windows ${code}).`);
}
function sidText(sid) {
  const text = [null];
  if (!sidToString(sid, text)) throw failure('identity');
  try { return koffi.decode(text[0], 'char16_t', -1); }
  finally { localFree(text[0]); }
}
function currentSid() {
  const token = [null], size = [0];
  if (!openToken(currentProcess(), 8, token)) throw failure('process identity');
  try {
    tokenInfo(token[0], 1, null, 0, size);
    if (!size[0] || size[0] > 65536) throw failure('identity size');
    const bytes = Buffer.alloc(size[0]);
    if (!tokenInfo(token[0], 1, bytes, bytes.length, size)) throw failure('identity');
    return sidText(koffi.decode(bytes, 'void *'));
  } finally { close(token[0]); }
}
const user = currentSid();

function privateAttributes(directory, work) {
  const descriptor = [null], flags = directory ? 'OICI' : '';
  if (!fromSddl(`O:${user}D:P(A;${flags};FA;;;${user})(A;${flags};FA;;;SY)`, 1, descriptor, null)) throw failure('private permissions');
  try { return work({length: koffi.sizeof(SA), descriptor: descriptor[0], inherit: 0}); }
  finally { localFree(descriptor[0]); }
}
function noLinks(path) {
  for (let current = resolve(path);;) {
    const bits = attributes(current);
    if (bits === 0xffffffff) {
      const code = lastError();
      if (code !== 2 && code !== 3) throw failure('path inspection', code);
    } else if (bits & REPARSE) throw Error('Private voice configuration cannot traverse a link or junction.');
    const parent = dirname(current);
    if (parent === current) return;
    current = parent;
  }
}
function requirePrivate(handle) {
  const owner = [null], acl = [null], descriptor = [null];
  const error = getSecurity(handle, 1, 5, owner, null, acl, null, descriptor);
  if (error) throw failure('permission inspection', error);
  try {
    const control = [0], revision = [0];
    if (!getControl(descriptor[0], control, revision)) throw failure('permission flags');
    if (sidText(owner[0]) !== user || !acl[0] || !(control[0] & 0x1000)) throw Error('Voice configuration must have protected permissions owned by this Windows user.');
    const info = Buffer.alloc(12);
    if (!aclInfo(acl[0], info, info.length, 2)) throw failure('access rules');
    let userAccess = false;
    for (let i = 0; i < info.readUInt32LE(0); i++) {
      const ace = [null];
      if (!getAce(acl[0], i, ace)) throw failure('access rule');
      const header = Buffer.from(koffi.decode(ace[0], 'uint8_t', 8));
      if (header[0] !== 0 || header.readUInt16LE(2) < 16) throw Error('Voice configuration has an unsupported access rule.');
      const identity = sidText(ace[0] + 8n), mask = header.readUInt32LE(4);
      if (identity !== user && identity !== 'S-1-5-18') throw Error('Voice configuration grants another Windows identity access.');
      if (identity === user && (mask & FULL) === FULL) userAccess = true;
    }
    if (!userAccess) throw Error('Voice configuration is not writable by its Windows owner.');
  } finally { localFree(descriptor[0]); }
}
function withFile(path, {directory = false, create = false} = {}, work) {
  noLinks(path);
  return privateAttributes(directory, sa => {
    const handle = createFile(resolve(path), create ? 0xc0000000 : 0x80000000, 1, sa,
      create ? 1 : 3, 0x00200000 | (directory ? 0x02000000 : 0), null);
    if (handle === null || handle === -1n || handle === 0xffffffffffffffffn) {
      const code = lastError();
      if (create && (code === 80 || code === 183)) return false;
      throw failure('open configuration', code);
    }
    try {
      const info = Buffer.alloc(52);
      if (!fileInfo(handle, info)) throw failure('file inspection');
      const bits = info.readUInt32LE(0);
      if ((bits & REPARSE) || Boolean(bits & DIRECTORY) !== directory || (!directory && info.readUInt32LE(40) !== 1)) throw Error('Voice configuration must be an ordinary single-link file.');
      requirePrivate(handle);
      return work(handle);
    } finally { close(handle); }
  });
}

export function privateDirectory(path) {
  path = resolve(path); noLinks(path);
  if (attributes(dirname(path)) === 0xffffffff) privateDirectory(dirname(path));
  privateAttributes(true, sa => {
    if (!createDirectory(path, sa)) {
      const code = lastError();
      if (code !== 183) throw failure('create configuration folder', code);
    }
  });
  withFile(path, {directory: true}, () => {});
}
export function privateRead(path) {
  return withFile(path, {}, handle => {
    const data = Buffer.alloc(65537), count = [0];
    if (!readFile(handle, data, data.length, count, null)) throw failure('read configuration');
    if (count[0] > 65536) throw Error('Voice configuration exceeds its size limit.');
    return data.subarray(0, count[0]).toString('utf8');
  });
}
export function privateCreate(path, text) {
  const written = withFile(path, {create: true}, handle => {
    const data = Buffer.from(text), count = [0];
    if (data.length > 65536) throw Error('Voice configuration exceeds its size limit.');
    if (!writeFile(handle, data, data.length, count, null) || count[0] !== data.length || !flush(handle)) throw failure('write configuration');
    return true;
  });
  // A retry validates an existing file; it never overwrites or "repairs" a
  // foreign identity's permissions or rotates a token used by another client.
  if (!written) privateRead(path);
}

export function privateReplace(path, text) {
  path = resolve(path);
  withFile(dirname(path), {directory: true}, () => {});
  // Validate the existing object before writing a replacement. This is an
  // owned preference update, never a repair of another identity's file/ACL.
  privateRead(path);
  const temporary = path + '.' + randomUUID() + '.tmp';
  try {
    privateCreate(temporary, text);  // Explicit current-user owner and flushed bytes.
    if (!moveFile(temporary, path, 1 | 8)) throw failure('replace configuration');
  } finally {
    try { unlinkSync(temporary); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
}
