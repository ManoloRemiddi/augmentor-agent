<!-- Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT -->

# Resonant Voice

Local, interruptible English voice for DSH and Augmentor Agent, using your existing
agent session with a separate Breeze speech engine and CPU speech recognition.

**Status: 0.1.16 Linux installation preview, 20 September 2026.** The native
interface supports hold/release, slide-to-lock and optional hands-free capture.
The package now includes a pinned Linux engine/service installer; choose CPU or
an explicit NVIDIA GPU UUID. It never moves or resizes another model. Actual
microphone/speaker and conversational latency acceptance remain machine-specific.

The developer's installed Qwen and Breeze currently both use the RTX 5090, with
CPU ASR/VAD. This is a recorded deployment, not a hardware requirement or the
configuration shipped to other people. See [deployment and rollback](docs/DEPLOYMENT.md).

- [18 September audit, drift and remaining qualification](docs/AUDIT-2026-09-18.md)
- [Build, run, install and current limits](docs/RUNNING.md)
- [Versioned audio/session protocol](docs/PROTOCOL.md)
- [Architecture and delivery plan](docs/PLAN.md)
- [Hardware evidence, experiments and acceptance](docs/QUALIFICATION.md)
- [Smaller Breeze quantizations and runtime compatibility](docs/QUANTIZATION.md)

DSH retains the conversation, selected model, reasoning policy, permissions and tools. Resonant Voice adds a replaceable speech service and a thin DSH plugin. Microphone and playback controls integrate into Augmentor's existing native and browser surfaces.

The objective is natural conversation with minimal perceptible waiting, not merely faster-than-real-time audio generation. Simple warm replies have a proposed target of median ≤700 ms and p95 ≤1,200 ms from actual end of user speech to first substantive audio. These are unverified acceptance targets. Tool work, deep reasoning and cold starts are measured separately; acknowledgments do not count as answers.

No dependency on Resonant CORE or an unreleased Resonant API is implied by the name. Package name: `dsh-resonant-voice` (versioned local tarball; not published to npm). Source is maintained in this repository and supplied as a reviewed source snapshot in the public complete Augmentor bundle, with UI integration in [augmentor-agent](https://github.com/ManoloRemiddi/augmentor-agent).

Repository-authored material is MIT licensed. Breeze weights, derivatives and self-hosted outputs have separate research/non-commercial terms; selecting Breeze here does not change those terms. Models and recordings are not bundled. See the [Breeze model card](https://huggingface.co/BreezeBlue/Breeze-TTS-2).

## Documentation and continuation

Start with the [agent handoff and documentation index](docs/AGENT-HANDOFF.md) for
component ownership, cross-repository Git refs, reproducible checks and open work.
GitHub holds the maintained descriptions; dated deployment entries retain their
original evidence and do not override the current package/source status.

## Measured development evidence

- Actual Breeze Q4 CPU synthesis: 0.881 s to first PCM, 8.174 s to produce 3.2 s of audio. CPU Breeze is too slow for continuous playback.
- Actual Whisper small.en CPU recognition of that synthetic English sample: 0.719 s. This is not a microphone/accent assessment.
- Real companion + real CPU speech engines: 1.456 s from submitted synthetic audio endpoint to first returned PCM, using injected assistant text. **No LLM latency is included.**
- Real DSH lifecycle integration and install/remove proof passed with fixture LLM/TTS. Native and browser regression evidence is recorded in the qualification document.

The native preview retains hold/release and slide-to-lock recording. To use hands-free, choose Settings → Resonant Voice → Conversation → Hands-free conversation, save, then tap the existing icon. Tap again or press Escape to stop. Pause tolerance defaults to 800 ms and is adjustable. Detection pauses during transcription, resumes while the agent works, and allows interruption during playback. Browser hands-free and semantic end-of-utterance prediction are not part of this release.

### Current voices and delivery

The selected voice stays consistent across passages. The active library is Clara, Ava, Zoe, Alice, Emilia, Ben, Daniel, Marcus, Eden and Sage. The requested removed voices remain absent. Settings allow preview, selection, playback speed and volume.

Emotions are neutral, warm, sad, excited, playful and calm. Automatic speed hints are capped at ±3% of the selected playback speed. Optional structured laughter becomes a Breeze vocal event; text remains unchanged. The model chooses its own conversational wording and delivery, with no canned test sequence. Laugh naturalness and speaker echo rejection are listening acceptance items. See [qualification](docs/QUALIFICATION.md) and [hands-free design](docs/HANDS-FREE-PROPOSAL.md).

## September source snapshot

The 0.1.14 snapshot includes the speech companion, DSH adapter, CPU ASR workers,
Breeze runtime helpers, saved synthetic voice references, playback preferences,
emotional delivery, and the session/generation protocol used by native hands-free
conversation. Native/browser UI code belongs to Augmentor, not this package.

Verification on 19 September: 33 Node tests and 3 Python ASR tests pass. The
standalone DSH lifecycle and packaged install/remove proofs are separate checks.
Human microphone recognition, speaker echo rejection, laughter naturalness and
end-to-end conversational latency still require listening/room acceptance.

The [.breeze references](voices/README.md) are generated speech assets with
separate upstream terms; they are not covered by the source-code MIT grant.
