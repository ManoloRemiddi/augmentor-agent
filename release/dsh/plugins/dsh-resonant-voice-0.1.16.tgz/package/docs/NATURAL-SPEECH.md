<!-- Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT -->
# Natural speech correction — 0.1.12

The fixed demo tool, stock wording and automatic routing of test requests to a preset sequence have been removed. No audition workflow is active. The model writes its own reply to the current conversation and supplies speech metadata for its own passages. Normally one passage suffices; multiple passages allow a change in delivery within the answer without audible emotion labels or a prescribed order.

`resonant_voice_reply` now advertises `{segments:[{text,speech:{emotion,speedMultiplier}}]}`. It accepts 1–8 passages, up to 1000 characters each and 4000 total. Legacy text/speech input remains accepted for transition. The displayed text is derived from these exact passages, never a separate summary. Per-passage settings are snapshotted, queued and interruptible. The service validates that the displayed text matches the passages. It synthesizes each cleaned passage as a coherent unit, avoiding sentence-by-sentence restarts in the companion. Breeze may still split long text internally.

The duplicate-output gate remains: when a model attempt includes the structured reply tool, its ordinary preamble is not also spoken. Native rendering retains compatibility with historical demo results so old sessions do not regain duplicate replies; that historical recognition does not register or execute a demo tool.

Breeze generation.cpp was inspected: the instruction is embedded in the conditional prompt even with cached reference codes. Directions are received, not discarded. Joy and sadness directions are now more explicit. Clara's reference, seed and user playback preferences remain unchanged. No guidance-strength/GPU/model change was made. Correct routing and different generated audio do not prove convincing emotional expression; that requires listening.

Verification includes model-generated conversational passages, independent delivery settings, exact visible/spoken wording, coherent synthesis, malformed input, cancellation and duplicate suppression. Fixed fixtures in developer tests are test data only and are not injected into user conversations. The standalone model checks do not submit messages into the user's chat.
