<!-- Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT -->

# Smaller Breeze builds

Research update: 17 September 2026, following the user's request to look for smaller quantizations. No weights were downloaded or executed. API file sizes below are exact observations at inspection; runtime/quality claims are attributed to their publishers and remain unverified locally.

The earlier 4.73 GiB number described **one audio.cpp Q8 package**, not the smallest Breeze model. Smaller variants materially improve the single-5090 proposal. They do not yet demonstrate a complete speech stack fitting the current 2,413 MiB (2.356 GiB) of free VRAM with headroom.

## Candidate matrix

| Build | Main file on disk | Companion/serving constraint | Priority |
| --- | --- | --- | --- |
| HoppouAI Q4_K | 2,538,909,376 bytes / 2.365 GiB | Its Breeze-TTS-2.cpp runtime; validate complete vocoder packaging | First compact candidate |
| HoppouAI Q6_K | 3,069,969,664 bytes / 2.859 GiB | Same runtime | Quality/capacity middle point |
| HoppouAI Q8_0 | 3,568,844,480 bytes / 3.324 GiB | Same runtime | Same-engine quality reference |
| cstr/CrispASR Q4_K | 2,206,392,384 bytes / 2.055 GiB | Separate tokenizer codec: 0.271 GiB Q8 or 0.334 GiB F16 file; qualify the supported pairing | Secondary compact candidate |
| alimpfard CUDA INT4 | 3,516,556,794 bytes / 3.275 GiB | Audio tokenizer weights 0.635 GiB; special loader, host embedding lookup offload and decode graphs | CUDA-focused candidate |
| audio.cpp Q8_0 | 5,079,668,352 bytes / 4.731 GiB | audio.cpp package layout | Established design baseline, not smallest build |

HoppouAI main-file sizes are from [its file listing](https://huggingface.co/HoppouAI/Breeze-TTS-2.cpp/tree/main). Its publisher describes ordinary Q4_K as retaining acceptable quality and estimates roughly 3 GB VRAM in the [runtime README](https://github.com/HoppouAI/Breeze-TTS-2.cpp); the model card gives a looser file-size-plus-overhead rule. Treat those as estimates, not a precise admission budget. This implementation uses Vulkan. Its experimental `-dd` variants further quantize the depth decoder but have reported degradation on long speech; exclude them from the default shortlist. Runtime revision inspected: `a5436642d4c64304b398ceeda9b8fce4577bfdb1`.

The [CrispASR model card](https://huggingface.co/cstr/breeze-tts-2-GGUF) explicitly excludes the codec and removes unused original tensors. Its [codec files](https://huggingface.co/cstr/qwen3-tts-tokenizer-12hz-GGUF/tree/main) are 290,623,616 bytes (Q8) or 358,453,280 bytes (F16). Main plus codec is therefore approximately 2.326 or 2.389 GiB on disk, before any working memory. Verify actual streaming service and cancellation support before selecting this runtime.

[alimpfard's INT4 card](https://huggingface.co/alimpfard/breeze-tts-2-int4) reports about 2.91 GB peak on a 3080 Laptop with host embedding lookup offload and decode-only CUDA graphs. That is not all weights resident on GPU and is not a 5090 measurement. Its loader and kernels require separate qualification. This targeted lookup offload is worth testing; it differs from moving the per-frame generative workload to CPU. The card uses ambiguous “RTF”/speed notation, so do not translate it into a promised response time.

## Serving behavior matters as much as quantization

[HoppouAI's WebSocket contract](https://github.com/HoppouAI/Breeze-TTS-2.cpp/blob/main/docs/websocket.md) supports incremental text, explicit flush, binary PCM and cancellation. It buffers sentences, so use measured clause-boundary flushes for the first spoken phrase; token arrival alone will not start sound. The README mentions two-second codec chunks, which must be reconciled with measured first-audio latency before selecting it for the sub-second goal. Smaller weights do not guarantee faster first audio than audio.cpp's CUDA path.

These are different implementations and GGUF schemas. A smaller file from one cannot be assumed loadable by audio.cpp or the LLM's llama-server. Preserve the adapter boundary and record the complete converter, weights, codec, engine and backend combination.

audio.cpp itself advertises Q4 storage conversion options. Measure those separately if needed: shrinking its weights may retain different tensor/codec coverage and numerical behavior than HoppouAI or CrispASR Q4_K. Conversion/load peaks also count.

## Other variants examined

- [EvoAwaken Q4_0](https://huggingface.co/EvoAwaken-Workshop/Breeze-TTS-2-gguf): requires a separate codec; publisher reports degraded stopping/output behavior, CPU-only validated execution and no streaming API. Exclude from this real-time shortlist.
- [mesmertech HQQ INT4](https://huggingface.co/mesmertech/Breeze-TTS-2-int4-hqq-g64): publisher reports about 5.20 GiB after warmup for its recipe and requires a custom loader. It is not the tightest memory candidate; artifact validation is distinct from the reported recipe tests. Its Apache label conflicts with the current base model's stated restrictions; do not assume that label changes model rights.
- MLX 4-bit packages target a different runtime ecosystem and do not establish an NVIDIA Linux deployment path.

## Revised experiment order

1. Confirm exact runtime/package contents and GPU compatibility for HoppouAI Q4_K, Q6_K and the compact CUDA INT4 route; retain Q8 and original Breeze as references.
2. Measure startup/steady/overlap peaks and first audible output. Test English technical terms, expressive delivery, sentence joins and at least 90 seconds of continuous speech. Compare matched prompts across several seeds; listen for drift, early stops, repetition and voice changes.
3. Add the selected streaming ASR and test single-5090 fit using the current Qwen profile if the measured budget allows. If it does not, propose the minimum context/concurrency tradeoff rather than immediately assuming the earlier Q8 budget.
4. Keep the smallest build that passes quality and latency, not simply the smallest file. Use the 5060 Ti if safe single-card fit or responsiveness still fails.

All Breeze derivatives retain applicable base-model terms. Package size, publisher VRAM and local peak VRAM must remain separate columns in the eventual results.
