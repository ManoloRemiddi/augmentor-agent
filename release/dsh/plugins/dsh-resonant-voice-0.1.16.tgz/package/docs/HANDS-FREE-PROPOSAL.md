<!-- Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT -->
# Conversational voice proposal — 19 September 2026

Status: original design below; the native conversation/VAD/AEC portions are implemented in the 0.1.13 candidate. Proactive notifications, semantic endpoint prediction and acoustic acceptance remain outstanding. Manual mode stays the default. Preserve the 0.1.12 backup independently. The inspected baseline records the earlier 0.1.10 state, not current feature availability.

## Inspected baseline

- Native voice.py owns one 16 kHz microphone stream and 24 kHz playback. Hold/release, slide-to-lock, ten-minute limit, waveform, manual interruption and generation invalidation already exist.
- The ASR worker runs small.en on completed utterances. `vad_filter=True` filters input during transcription; it is not live endpoint detection. No partial ASR or semantic end-of-utterance model is active.
- Playback-ready currently checks service speech-idle and the local pending PCM queue. That is not a device-drained acknowledgment and must not be used alone for automatic listening transitions.
- Structured speech version 1 already carries text, emotion and relative speed through a terminal DSH tool. The current terminal response waits for the complete short response. It does not add another model call. Breeze has instruction-based direction, not an SSML parser or guaranteed word-emphasis control.
- MX reports PulseAudio on PipeWire 1.4.5, a Rode VideoMic NTG input and analog stereo output. No echo cancellation appeared in the PulseAudio module listing. Native capture requests no explicit echo cancellation; actual hardware echo performance is unqualified.
- MX App Monitor already has enabled-host profiles, bounded SSH JSON collectors, device identity checks, and storage readings. Reuse via a versioned export interface rather than starting duplicate probes or importing private implementation files across repositories. An event export endpoint has not been established by this audit.
- machine-map.md includes alternate aliases for the same devices, a LAN fallback and intentionally offline exclusions. It is inventory documentation, not an executable polling list.

## Proposed interaction

Add an explicit Hands-free mode in Resonant Voice settings; retain current manual mode. In Hands-free mode one tap starts the conversation and a second tap stops speech, capture and automatic rearming. Escape has the same stop meaning. The existing icon shows listening, processing and speaking states; no popup is needed. A settings pause-tolerance control supports users who think while speaking.

Keep one microphone capture stream alive only during the active hands-free session. The capture callback must only enqueue bounded audio; resampling, AEC and VAD run outside the real-time callback. Use a small in-memory pre-roll ring (initially 250–400 ms) to preserve initial consonants. Discard it when the session ends. Silence alone is never submitted.

Use Silero ONNX on CPU for initial live VAD. Its speech probability does not prove conversational completion. Start endpoint trials around 600–900 ms silence, with a longer-pause option. Treat these as tunable candidates, not measured optimal values. Shorter 150–350 ms guards from the earlier plan belong to a qualified semantic endpointing pipeline, not VAD alone. Add hysteresis and minimum voiced duration to reject clicks and transient sounds. Keep the ten-minute per-utterance safeguard, with automatic segmentation in hands-free mode rather than ending the whole conversation.

State machine: Off → Listening → Capturing → Finalizing → Waiting → Speaking → Listening. Speech onset can also interrupt Speaking or steer Waiting. Establish one audio generation and one user-request identity per accepted utterance; duplicate endpoints, delayed tool results, reconnection and cancel must not replay input or old speech. Device failure and explicit Stop transition to Off. Do not automatically restart after a fault or reconnect.

For automatic continuation, require both terminal turn state (not merely a tool step ending) and audible playback completion. The native client should acknowledge consumed frames plus device latency/tail for the correct generation. The server finishing synthesis is insufficient. When the agent performs a long tool task, continued listening allows a user follow-up but does not manufacture a fresh turn from silence.

## Barge-in and echo

First qualify automatic interruption with headphones. For speakers, evaluate a dedicated PipeWire WebRTC echo-cancel source/sink pair. Route Resonant playback through the paired sink so the canceller has the far-end signal; microphone processing alone cannot remove known output reliably. Do not change the global default devices. Verify installed module availability and resampling/delay behaviour before selecting this backend.

Run speech detection on the cleaned microphone signal. Confirmed near-end speech clears native playback immediately, invalidates the old TTS generation, retains pre-roll and captures the new utterance. Measure a candidate onset-to-local-mute target of 150–250 ms, including confirmation time. This is a test target, not a guarantee. Do not wait for final ASR before muting. Stop audio independently from DSH task cancellation: steer through existing DSH semantics, preserve unknown-outcome actions, and never automatically repeat a tool operation.

## Delivery metadata

Reuse the version-1 contract and selected voice. Keep calm and the existing relative-speed limits; add serious only if listening tests show a useful distinction. Do not rename fields or widen limits just to match the proposal. Future adapters advertise supported controls. Breeze maps emotion to instruction and speed to pitch-preserving processing. Unsupported emphasis remains unsupported; inserting SSML would not make Breeze honor it. A streaming structured-segment response is a separate optimization requiring stable DSH response/commit semantics, not parsing arbitrary prose or acting on incomplete JSON.

## Proactive notifications

Add a separate, initially disabled notification producer on MX after conversation turn-taking is stable. Prefer existing monitor events and explicit job completion signals. A five-minute reconciliation poll is useful for recovery but can delay detection by almost five minutes; debouncing adds more delay. Disappearing processes do not prove successful job completion: require a job identifier and an authoritative terminal status or exit code.

Import reviewed enabled devices into machine-readable configuration, deduplicate aliases, honor exclusions, and distinguish tailnet reachability from service health. Tailscale status JSON plus targeted bounded checks is preferable to repeatedly pinging every documented alias. Missing permissions or failed probes produce unknown, not confirmed offline. Use debounce, disk threshold hysteresis (candidate warn above 90%, rearm below 85%), deduplication, cooldowns, and atomic persisted state. First startup establishes a baseline without announcing every device. No indefinite replay of alerts after a restart.

Route notices through the Resonant companion, never directly to Breeze. Add a typed notification envelope (event ID, source, timestamp, expiry, priority, text, speech) and a shared playback scheduler. Preserve exclusive session ownership: background monitoring must not acquire/replace the user's microphone session. Defer ordinary alerts while the user speaks, the agent answers, or an interruption is unresolved; coalesce and expire them. Speech obeys opt-in, mute, quiet hours, desktop lock and output availability. Every spoken notice also appears in a text feed. Listening to a notice does not arm the microphone. Use short factual templates initially; no separate LLM or GPU is needed.

## Delivery order and gates

1. Instrument audible completion, then add CPU VAD and automatic continuation as a reversible mode. Validate silence, pauses, long speech, device loss, Escape and ten-minute segmentation.
2. Qualify headphone barge-in, then speaker AEC with the actual Rode microphone and output path. Test echo-only playback, double talk, first-word preservation, background speech and repeated interrupts.
3. Measure endpoint → ASR → DSH → TTS → audible output; report median/p95 separately for simple replies, long context and tool tasks. Compare against 0.1.10 and the pre-expression baseline. Do not infer latency from GPU fit.
4. Add notifications in text-only mode first; verify false-alert rate and deduplication before optional speech. Test conversational priority, quiet hours, mute, restart and stale events.

Keep Qwen on 5090 and Breeze on 5060 Ti during this work. CPU VAD/AEC and notification decisions are candidates for CPU execution; measure load. Do not evict or change model precision to improve timings.

## Primary references

- Silero VAD: https://github.com/snakers4/silero-vad
- PipeWire echo cancellation: https://pipewire.pages.freedesktop.org/pipewire/page_module_echo_cancel.html
- Tailscale status and ping: https://tailscale.com/kb/1080/cli
- Breeze voice direction: https://github.com/HoppouAI/Breeze-TTS-2.cpp#what-it-does
