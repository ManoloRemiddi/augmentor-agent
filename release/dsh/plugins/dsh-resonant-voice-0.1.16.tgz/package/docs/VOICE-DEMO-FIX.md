<!-- Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT -->
# Voice comparison and duplicate correction — 0.1.11

Historical record: the fixed demo described below was removed in 0.1.12. See NATURAL-SPEECH.md.

The reported session emitted ordinary text and the same text in a structured voice tool. Both were spoken and rendered. In expressive mode the plugin now buffers ordinary text per model attempt. If that attempt contains a voice reply/demo tool, only its structured result supplies speech. If no voice tool is chosen, committed ordinary text remains the fallback. Cancelled attempts do not flush buffered text. Legacy text streaming is unchanged. Native and browser presentation suppress ordinary prose in a committed message that carries a voice tool; the durable log is not rewritten.

`resonant_voice_demo({})` returns five fixed labelled samples, each with its own delivery metadata: neutral, warm, sad, excited, calm. The phrase, selected voice/reference and user playback speed stay constant across samples. One terminal call starts the comparison without another model round trip. Stop cancels queued samples. Samples are independently synthesized, so brief synthesis gaps may occur. Unsupported whispering/laughing/curious/hungry styles are reported as unavailable, not approximated with punctuation.

To test, open Resonant Voice and say: “Run the voice emotion comparison test.” The chat shows a comparison description once; the audio announces each label and then speaks the common sentence. A successful tool return means the structured request was produced, not that the listener heard or approved the emotional effect.

Regression coverage includes the observed mixed-prose/tool pattern, plain fallback, cancellation, distinct sample settings, duplicate event rejection, invalid sample batches and stopping partway through the demo. The same failed user prompt selected resonant_voice_demo in a standalone local Qwen probe. This probe does not prove all future prompts or acoustic quality.
