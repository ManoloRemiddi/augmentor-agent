<!-- Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT -->
# ASR vocabulary hint — 0.1.14

The worker's single built-in default is: `Augmentor. The user is talking to Augmentor on a Linux desktop.` It is decoder context, not text prepended to the transcript or a chat-system instruction. Recognition is not corrected by string replacement. The CPU small.en/int8 model, beam_size=1, VAD, condition_on_previous_text=False, early short-audio return and worker protocol are unchanged.

Override priority is worker `--initial-prompt` > `ASR_INITIAL_PROMPT` environment variable > built-in default. An empty flag or environment value passes None to the decoder and disables the hint. Keep custom hints to a couple of short natural English sentences; do not add model control tokens.

The actual launcher is `WhisperWorker` in the Node companion, not the Augmentor desktop process. The companion inherits its service environment. Optional `asr.initialPrompt` in `~/.config/resonant-voice/config.json` is forwarded as `--initial-prompt`, including an explicit empty string. If omitted, no CLI flag is passed, allowing the worker's environment/default precedence. The phrase is not duplicated in the launcher and ships automatically in each versioned worker. Restart the companion and reconnect voice after changing it; the selected vocabulary is fixed for that worker lifetime.

## Verification

Three Python tests passed (including five override/empty cases, unchanged decoder arguments, the short-input return and the existing complete ten-minute retention test). Thirty Node tests passed. The actual Node launcher was also exercised with the real CPU decoder and an explicit configured prompt.

Generated Clara speech was decoded by the actual worker with and without the hint:

| Sample | Empty hint | Default hint |
| --- | --- | --- |
| Name | Say my name, Augmentor. | Say my name, Augmentor. |
| Ordinary | Please put the blue notebook beside the window. | Please put the blue notebook beside the window. |
| Silence | empty | empty |

These are synthetic audio tests, not recordings of the user's microphone. Both modes already recognized the generated name correctly, so this does not establish an accuracy improvement for the user's pronunciation. The normal sentence stayed unchanged and silence produced no invented name. User microphone acceptance remains to be performed after installation. No test prompt or recording was submitted into the user's DSH conversation.

The exact runtime and version diff is saved at `outputs/asr-hotword-change.patch`; transcript results and timings are in `outputs/asr-hotword-recognition.json`.

Primary API reference: https://github.com/SYSTRAN/faster-whisper/blob/v1.2.1/faster_whisper/transcribe.py . The installed faster-whisper version and signature were also checked locally.
