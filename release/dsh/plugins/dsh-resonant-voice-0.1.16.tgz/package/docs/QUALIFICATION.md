<!-- Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT -->

# Hardware evidence and qualification protocol

For current source status, commands and cross-repository ownership, start with
[the agent handoff](AGENT-HANDOFF.md). The records below are chronological;
earlier push-to-talk-only, pending GPU authorization and unimplemented hands-free
statements apply to their original checkpoints, not the final 0.1.14 snapshot.


Historical pre-deployment read-only audit: 17 September 2026. No inference, audio recording, installation, service restart, eviction, cache resize or benchmark was performed. The audio.cpp source revision inspected was `c0b26a505468152ec1d0fc06ac252c824408fc07`, not a tested runtime pin.

Current deployed measurements supersede these historical observations: see [deployment](DEPLOYMENT.md).

## Pre-deployment observations

| Item | Observation |
| --- | --- |
| 5090 | 32,607 MiB total; 29,697 MiB used; 2,413 MiB free as reported; 94% utilization at one instant |
| 5060 Ti | 16,311 MiB total; 15,493 MiB used; 356 MiB free as reported; 0% utilization at one instant |
| Main Qwen process | PID 2016, 28,038 MiB on 5090; owned by `gpu-llm-5090.service`; port 8080 |
| Main model | Qwen3.8-27B-GSQ-RCO-IQ3_S-mtp GGUF; file 12,120,016,960 bytes |
| Main configuration | 524,288 total context, 2 parallel slots, q4_0 K/V, Flash Attention on, draft-MTP |
| Secondary Qwen | PID 259668, 15,470 MiB on 5060 Ti; `gpu-llm-5060ti.service`; port 8100 |
| Secondary configuration | Non-MTP Qwen3.8-27B-GSQ-RCO-IQ3_S; 188,416 total context, 1 slot, q4_0 K/V, Flash Attention, microbatch 128 |
| Other 5090 workloads | Unreal Editor approximately 1,042 MiB and Discord approximately 500 MiB; do not assume these allocations are reclaimable |
| Host | Ryzen 9 9900X, 12 cores/24 threads; about 60.5 GiB RAM; about 10.8 GiB available, swap almost full at inspection |
| Existing Breeze | Official PyTorch source, environment and safetensors already present under the shared AI storage; `breeze-tts-local.service` configured for GPU 1 but inactive |

These are snapshots, not stable budgets. Driver-reserved memory can account for differences between reported total, used and free; do not replace reported free with total minus used. High GPU utilization at one instant does not attribute load to one process. Occupied swap alone does not prove active swapping; measure memory pressure under experiments. Model startup logs were not accessible for a reliable KV/compute-buffer breakdown.

The 5060 Ti configuration has changed since 14 September. Do not rely on the earlier 65k/MTP snapshot when planning deployment. Locate callers and verify current service configuration before making it the speech card. Existing Breeze assets/service may be reusable, but presence is not proof of correct paths, current versions or working GPU qualification. Do not start that service into an already occupied card.

## Breeze capacity evidence

The [audio.cpp model repository](https://huggingface.co/audio-cpp/audio.cpp-gguf/tree/main/Breeze-TTS-2-GGUF) reports:

| File | Bytes | GiB on disk |
| --- | --- | --- |
| Q8_0 GGUF | 5,079,668,352 | 4.731 |
| BF16 GGUF | 7,342,916,800 | 6.839 |

File size is not peak VRAM. The fully GPU-resident audio.cpp Q8 design already exceeds the presently free 5090 memory before working buffers. This is not a lower bound for every Breeze implementation: [smaller Q4_K/INT4 variants](QUANTIZATION.md) are now first-stage candidates. Different converters include different tensors and codec assets; compare the entire required package and measured residency.

For screening the audio.cpp Q8 baseline only, reserve **6–8 GiB for TTS**, **1–3 GiB for ASR**, measured application memory, and **at least 2 GiB spare**. Under an illustrative 2 GiB application budget, this leaves roughly **17–21 GiB for Qwen** out of 31.84 GiB, versus its observed 27.38 GiB. This is not the requirement for all Breeze builds. A provisional **3–4 GiB compact-TTS** envelope with the same ASR/application/reserve assumptions leaves roughly **21–24 GiB for Qwen**, suggesting a smaller potential reduction of about 3.5–6.5 GiB. Neither envelope is a measured upper bound; exact ASR choice, CPU lookup offload, startup peaks and GUI workloads change the result. Qualify the compact build before proposing any context reduction.

Admission requires measured worst-case startup, steady-state and overlap peaks, not just successful weight loading. No precise savings from a context reduction are claimed until the installed server's allocation is measured. Current KV is already q4_0; do not present KV quantization as newly available savings.

## Experiments, in dependency order

All runs must record exact binary/model hashes, effective slot context, device UUID, voice settings, precision, warmup, background load and raw timings. Never run against a busy production GPU without agreeing a suitable test window. No GPU clocks or power settings need changing for this plan.

1. **Reference:** record existing Qwen behavior and latency for short/long contexts and one/two active sessions. Gather allocation breakdown and existing consumer requirements. Retain exact service configuration for restoration.
2. **Isolated speech:** qualify the complete smaller-quantization/runtime pairs in [QUANTIZATION.md](QUANTIZATION.md), then measure finalists with streaming ASR on a freed device. Compare against Q8 and official Breeze reference where feasible. Capture startup peak, resident memory, first PCM, generation rate, final transcription tail and English quality. Keep identical text/voice/seed where applicable, without assuming equal seeds make outputs equivalent across runtimes.
3. **Single-card admission:** compare approved Qwen total-context profiles (524,288 baseline; 262,144 and 131,072 candidates) while keeping the selected model, cache type and intended slot count explicit. If a profile reduces required context or concurrency, reject it rather than silently accepting the loss. Load ASR/TTS only after a measured budget supports them.
4. **Contention:** repeat audio/LLM pipeline with prefill, decoding, tool-result ingestion, second-chat traffic and the user's normal GUI workload. Test microbatch changes only when supported; larger batches may improve throughput but worsen speech scheduling. Do not assume CUDA stream priority or cross-process scheduling guarantees preemption.
5. **Split comparison:** run the same prompts and voice cases with Qwen on 5090 and speech on 5060 Ti. Include transport and capture/playback in the timing. Profile C (ASR split only) is useful only if the measurements identify ASR as the remaining bottleneck.
6. **Placement selection:** prefer A when it preserves required quality/context/concurrency, has ≥2 GiB measured reserve at peak, and passes user-facing targets. Choose B when A fails or introduces meaningful regressions. Keep C only if it produces a measured practical benefit. Unsuccessful profiles remain documented as failures, not silently retuned successes.

## What counts as real time

For each utterance record timestamps at last actual speech sample, endpoint decision, final ASR transcript, DSH submission, first user-facing model token, first coherent text segment, first PCM arrival, and audible playback. Measure from a common monotonic timeline or synchronized capture, including device buffering. GPU kernel timing or HTTP first byte alone is insufficient.

Proposed engineering targets for warmed simple conversation, all **unverified**:

| Measurement | Goal |
| --- | --- |
| End of actual speech → first substantive audible response | Median ≤700 ms; p95 ≤1,200 ms |
| Confirmed speech onset → stopped playback | p95 ≤150 ms; report actual-onset-to-stop too |
| Sustained Breeze throughput with ASR active | Prefer ≥2x playback speed (RTF ≤0.5), with no audible underruns in the acceptance session |
| Existing Qwen responsiveness under comparable load | No more than 10% regression in p95 first-text latency; no loss of required context/concurrency |
| Task correctness and voice quality | No material regression in paired evaluation; user listening acceptance required |

A rough allocation of a 700 ms warm-turn budget is endpoint/tail 200 ms, Qwen through a speakable clause 250 ms, first TTS PCM 200 ms, transport/playback 50 ms. This is a budget to disprove or meet, not a forecast; reasoning can consume seconds and cannot always fit it. A natural response across all tasks is not promised by this target. Report push-to-talk and hands-free separately, and track false endpoints alongside latency.

Use at least 100 representative short turns per finalist for a useful exploratory p95, plus separate long-context, reasoning and tool cases. Include the user's accent, technical names, negations, mid-sentence pauses, self-correction, silence, background speech, speaker echo, long answers and repeated interruptions. Test conversation quality with the user rather than inferring it solely from aggregate ASR word error rate. Record premature endpoints and wrong commands explicitly; task actions cannot be triggered by unstable transcripts.

Report cold entry/warmup, acknowledgment latency, substantive-answer latency, tool completion and compaction separately. Cached phrases cannot make the substantive-answer metric pass. Test at least 30 minutes of continuous interaction, disconnect/reconnect, worker crash, device denial, switched sessions and cancellation during tools/approvals. Record duplicate actions, stale audio, queue growth and out-of-memory events.

If a target fails, identify the dominating stage before changing models or placement. If Qwen reasoning is the bottleneck, moving TTS to the 5090 cannot remove it. The release claim must describe measured performance, including the contexts and loads that did not meet it.

## Primary references

- [Breeze model and runtime requirements](https://huggingface.co/BreezeBlue/Breeze-TTS-2)
- [audio.cpp Breeze options](https://github.com/0xShug0/audio.cpp/blob/main/docs/models/breeze_tts.md)
- [Q8/BF16 model files](https://huggingface.co/audio-cpp/audio.cpp-gguf/tree/main/Breeze-TTS-2-GGUF)
- [Parakeet streaming with EOU](https://huggingface.co/nvidia/parakeet_realtime_eou_120m-v1): candidate for integrated endpoint detection; published synthetic-audio EOU benchmarks are not results on the user's voice.
- [Nemotron English streaming ASR](https://huggingface.co/nvidia/nemotron-speech-streaming-en-0.6b): candidate for cache-aware incremental recognition.
- [llama.cpp server configuration](https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md): upstream reference; installed binary behavior must be checked independently.


## Implementation evidence — 17 September 2026

The user subsequently authorized building. The following are local observations, not upstream performance claims.

| Check | Evidence |
| --- | --- |
| Breeze source | a5436642d4c64304b398ceeda9b8fce4577bfdb1; ggml 36da57138425487184aa1da2eee2cde155909c6f; Vulkan build completed |
| Model | HoppouAI revision 81b22bad9f05b99970e30c5ee5e4bbc52fedf2f8; Q4_K 2,538,909,376 bytes; SHA256 483418fbbb438f5f1c08dbe2b017e42db0f1d126765cd3f772d8622a30a4915c |
| ASR | faster-whisper 1.2.1, CTranslate2 4.8.1, ONNX Runtime 1.28.0, NumPy 2.5.1; CPU INT8 small.en snapshot d1d751a5f8271d482d14ca55d9e2deeebbae577f |
| CPU TTS single sample | “Hello. Resonant Voice is ready for testing.”; first PCM 880.7 ms; total 8.174 s; audio 3.2 s; first chunk 4 frames, max 12 frames |
| CPU ASR single sample | Recognized “Hello? Resonant voice is ready for testing.” in 718.8 ms from the generated audio; no human listening or microphone test |
| Real speech companion smoke | Synthetic 16 kHz input → resident Whisper → transcript → injected assistant text → Breeze PCM; first output 1,456.4 ms after input end. Excludes DSH/LLM, capture, endpoint detection and physical playback |
| GPU mapping | Vulkan 1 = 5090 UUID 1d8d7f31-b0e5-05b1-ab9f-e85288782b24; Vulkan 2 = 5060 Ti UUID d51c173b-5302-65a1-27ba-84acd5faf19f. CUDA indices differ |
| Admission | 5090 launch correctly refused at 2,413 MiB free against a 4,608 MiB conservative threshold. No GPU model load or Qwen reconfiguration occurred |
| Plugin integration | Actual installed DSH 0.1.5-rc.1 lifecycle and session query, fixture LLM/TTS; wrong surface denied, reasoning excluded, selected model retained, plugin disposal checked |
| Packaging | Local 0.1.0 npm tarball installs, composes once, and removes in disposable DSH profile; live profile untouched |
| Native regressions | 276 tests passed using Augmentor's development venv and offscreen Qt; includes three new voice tests. Microphone and speakers were not used |
| Browser regressions | 18 tests passed, including simulated microphone ownership, exactly-once finalized submission, and release on navigation. Not a Chrome microphone-permission acceptance test |

Logs, measurements, preview screenshot, downloaded model and compiled binaries are retained under ignored `outputs/` and `models/`. Protocol tests are fixtures and must not be reported as a measured real-time conversation. The one CPU sample is insufficient for p50/p95 and quality claims. CPU Breeze fails throughput; no card has been demonstrated to meet the real-time target. Sub-second experience remains unachieved.

The current adapter intentionally uses utterance-based ASR and push-to-talk. The planned streaming ASR/EOU, hands-free echo handling and user voice-reference selection still need implementation/qualification. Before live enablement, obtain the user's pending decision about the secondary Qwen workload; measure the selected GPU's peak memory, warm TTS throughput and end-to-end latency, then run microphone/listening/tool/Stop acceptance in both surfaces.

## 19 September: modest pace, explicit laughter and hands-free

The 0.1.13 candidate clamps automatic delivery hints to 0.97–1.03 of the user's selected speed, independently of emotion. Clara, seed 83, remains selected; a base speed of 1.2 therefore ranges from 1.164 to 1.236. Playful direction asks for amusement at a relaxed pace. The response contract accepts optional `speech.laughter: "before" | "after" | "none"`; displayed text remains the agent's own words. Only the Breeze adapter inserts `(laugh)` around that passage. No fixed demonstration, prerecorded laughter or punctuation-based emotion detector is involved.

Upstream Breeze documents `(laugh)` as a supported vocal event and recommends CFG 2–3 for vocal events, at a computation/harshness cost. The candidate uses CFG 2 only for passages explicitly requesting a laugh; ordinary speech stays at CFG 1. This is a real model-generation request, not a guarantee of naturalness. Listening remains necessary to judge identity, humor, harshness and whether the laugh suits the words. Sources: https://github.com/HoppouAI/Breeze-TTS-2.cpp and https://huggingface.co/BreezeBlue/Breeze-TTS-2 .

The DSH bridge publishes `turn-complete` only on `agent/status: idle`, which the installed 0.1.5-rc.1 runtime documents as no driver scheduled or active. The event shares the ordered response transport and current request ID. A stream end or `agent/turn-stopping` is insufficient: tools or steering can follow. The companion validates session/request/capture state before forwarding completion with the current audio generation. Silent final turns also signal speech-idle. Native playback-drained acknowledgments are advisory and cannot authorize a new microphone session.

Local candidate evidence: 30 Node service/contract tests passed; actual DSH 0.1.5-rc.1 lifecycle integration confirmed request-bound terminal ordering; actual ToolRuntime accepted playful+laughter metadata and concluded the turn. In an isolated model request, Qwen authored an original joke, selected playful and laughter-after, and retained speed 1. The companion synthesized those exact words with Clara at the user's 1.2 base speed: complete 8.85 s audio, 8.82 s wall time including paced delivery. No fixture wording was injected into the user's conversation.

Two isolated raw Breeze vocal-event samples measured first PCM at 188 ms (CFG 1) and 439 ms (CFG 2), with zero clipped samples in either; respective generation times were 2.49 s and 3.31 s for approximately 6.1 s audio. These are single samples without ASR/LLM/device latency, not median/p95 measurements or auditory acceptance. The stronger vocal-event setting is reserved for requested laughs.


## Linux installer qualification — 20 September 2026

Version 0.1.15 adds explicit-device Linux provisioning. Source suites passed 33
Node tests and 10 Python tests (including four installer safety/plan checks).
The new installer is exercised in an isolated data/config tree with no user
services activated and no GPU workload changes. Final runtime/build evidence is
recorded with the complete Augmentor distribution audit. Model weights are not
part of the public archive; the download revision and SHA-256 are pinned.

## 20 September incremental recognition qualification

See [incremental ASR](INCREMENTAL-ASR.md) for eight worker regressions, 34 Node
tests, real CPU replay measurements and their limits. Provisional recognition is
verified before end-input. Physical microphone/echo and end-to-end model response
time remain separate acceptance checks.
