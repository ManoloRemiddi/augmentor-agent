<!-- Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT -->

# Agent handoff and documentation index

GitHub is the durable source of truth for this speech package. Current source is
[resonant-voice](https://github.com/ManoloRemiddi/resonant-voice), branch `main`,
package **0.1.16**. Initial published implementation is
[`cac49f6`](https://github.com/ManoloRemiddi/resonant-voice/commit/cac49f6).
Read [AGENTS.md](../AGENTS.md) before changing code or installed services.

Augmentor owns the UI and automatic memory in
[augmentor-agent](https://github.com/ManoloRemiddi/augmentor-agent).
Its current desktop development is [draft PR #3](https://github.com/ManoloRemiddi/augmentor-agent/pull/3),
branch `productization/shared-memory-and-desktop`; see that branch's
[handoff](https://github.com/ManoloRemiddi/augmentor-agent/blob/productization/shared-memory-and-desktop/docs/AGENT-HANDOFF.md).
Do not expect Augmentor's unmerged development changes on `main`.

## September 20 installation update

Version 0.1.15 adds `bin/setup-linux.py` for pinned runtime/model downloads,
explicit CPU/GPU placement, CPU ASR, private configuration and user services.
The complete Augmentor installer calls it only after an explicit voice choice.
At that point the running developer companion remained 0.1.14; the subsequent
0.1.16 guarded deployment below supersedes that installed status.

## September 20 incremental recognition update

Version 0.1.16 replaces end-only recognition with bounded CPU recognition during
capture. See [incremental ASR and latency](INCREMENTAL-ASR.md) for the algorithm,
measurements, regression evidence and remaining model/physical-audio qualification.
The additive protocol keeps provisional text out of the agent submission path.
The installed companion is now 0.1.16; the DSH plugin remains compatible 0.1.14,
and desktop, secondary and mobile windows now run the selected playback fix
after a subsequent user-requested graceful restart. See
[deployment evidence and rollback](DEPLOYMENT.md#20-september-2026-incremental-asr-0116).
Native playback buffering is owned by Augmentor, not copied into this package.

## Ownership and source map

| Source | Responsibility |
| --- | --- |
| `src/` | Speech companion, configuration, authenticated session/generation protocol, DSH plugin |
| `workers/` | Replaceable CPU ASR workers and pinned Python dependencies |
| `bin/` | CLI, Breeze launch/device checks and diagnostics |
| `voices/` | Catalogued synthetic references and audition clips; separate upstream asset terms |
| `test/` | Service/protocol tests, DSH lifecycle integration and tarball install/remove proofs |
| Augmentor native `voice*.py` and browser voice modules | UI, microphone/playback and hands-free integration; not duplicated here |

DSH remains the only conversational agent. Preserve its selected model, session,
permissions, Stop, steering and unknown-outcome behavior. Speech is not the memory
owner: Augmentor captures committed voice transcript/reply text for its separate
Hindsight relationship/project banks. Voice mode is not speaker authentication.
Do not add sibling-checkout runtime imports; use the versioned package contract.

## Guide index

| Guide | Purpose |
| --- | --- |
| [Running](RUNNING.md) | Dependencies, build, config, CLI and DSH tarball installation |
| [Protocol](PROTOCOL.md) | Authentication, session/generation and audio wire contract |
| [Deployment](DEPLOYMENT.md) | Dated local installation, corrections and rollback; earlier entries are historical |
| [Qualification](QUALIFICATION.md) | Measured results, test commands and acceptance boundaries |
| [Architecture plan](PLAN.md) | Original design and staged work, not proof all planned features shipped |
| [Hands-free proposal](HANDS-FREE-PROPOSAL.md) | Design, constraints and acceptance; current native behavior is in Augmentor's hands-free guide |
| [Structured speech](STRUCTURED-SPEECH.md) | Delivery metadata and speech integration |
| [Natural speech](NATURAL-SPEECH.md) | Voice/prosody behavior and listening limits |
| [Voice library](VOICE-LIBRARY.md) | Selection/reference handling |
| [Incremental ASR](INCREMENTAL-ASR.md) | Streaming recognition, pipeline timing and measured limits |
| [ASR hotwords](ASR-HOTWORDS.md) | Recognition vocabulary behavior |
| [Quantization](QUANTIZATION.md) | Tested model/runtime combinations and resource constraints |
| [18 September audit](AUDIT-2026-09-18.md) | Dated measurements, drift and remaining checks |
| [Demo correction](VOICE-DEMO-FIX.md) | Specific historical fix and evidence |
| [Voice asset terms](../voices/README.md) | Synthetic assets and licensing distinct from MIT source |

## Reproduce checks and package

Use tested Node 24.19.0 and the Python environment described in the running guide.

```sh
npm ci --ignore-scripts
npm test
python3 -m unittest discover -s test -p 'test_asr*.py' -v
node test/dsh-integration.mjs
mkdir -p outputs
npm pack --pack-destination outputs
node test/install-proof.mjs outputs/dsh-resonant-voice-0.1.16.tgz
```

The DSH integration uses `DSH_INSTALL_ROOT` (absolute package root of DSH
0.1.5-rc.1); its fallback is the original developer installation path. Set it on
a fresh machine. The install proof requires that compatible `dsh` executable
on `PATH` and uses a disposable profile. Python worker tests need NumPy in the
selected environment and stub recognition inference; they are not ASR accuracy
benchmarks. See [qualification](QUALIFICATION.md) for measured engine evidence. The
19 September source snapshot passed 33 Node tests, 3 Python ASR tests, actual DSH
lifecycle integration and package install/remove with fixture LLM/TTS. That is
not physical microphone/speaker or human listening qualification. Ignored local
outputs are not available to a fresh clone; keep result summaries and reproducible
commands in these guides rather than relying on a developer's logs.

## Deployment and remaining work

Current user-directed placement is Qwen and Breeze Q4 on the RTX 5090, with CPU
ASR/VAD. The previous 5060 Ti fallback is superseded; see the latest deployment
entry for the result. Never change placement or Qwen context to compensate for
a failure without notifying the user and receiving their direction. Inspect
actual service/config state before acting; never change GPU workloads or model
precision/context silently. Native preview supports hold/release, slide lock and
optional hands-free with PipeWire echo cancellation. Browser hands-free is not
qualified. Published source, installed speech tarball and installed UI are separate
versions and must be checked independently. The package is not published to npm.

Human microphone recognition, echo/double-talk rejection, interruption quality,
laughter naturalness and full conversational latency remain acceptance work.
Automatic-memory continuity needs a real two-session user voice trial as recorded
in Augmentor's handoff. Sub-second targets are goals, not established results.

Update the owning guide and this index when changing a contract, setup or feature.
Record exact tested ref, fixture/live distinctions, installation/rollback impact
and open work in GitHub. Keep private configuration, recordings, tokens, models
and raw user transcripts out of commits. Preserve model/output license boundaries.
