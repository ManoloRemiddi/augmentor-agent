<!-- Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT -->
# Build and run the development preview

Current source package is Resonant Voice **0.1.16**, with native hold/release, slide-lock and optional hands-free support. Verify the installed package separately. See [current deployment, measured latency and rollback](DEPLOYMENT.md). Native controls expand below the composer and consume DSH text as it streams. See the [current audit](AUDIT-2026-09-18.md) for measured results. Human acoustic hands-free quality and sub-second response targets remain unqualified.

## Guided Linux installation

Use the complete Augmentor bundle for Debian dependencies, plugin registration
and the desktop microphone environment. For a separately provisioned fresh Linux
host, the package also provides:

```sh
python3 bin/setup-linux.py --accept-model-license --cpu --node /absolute/path/to/node
```

Or select `--gpu GPU-EXACT-UUID` instead of `--cpu`. This builds the pinned Breeze
runtime, verifies the pinned model download, creates a dedicated ASR environment,
installs synthetic voice references and enables the two speech user services.
`--plan` shows the selected versions/device without changing files. Existing
unmanaged voice configurations are refused for reviewed migration. CPU synthesis
is slower; this is not a promise of real-time voice on every machine. The model
and generated voice assets keep their separate research/non-commercial terms.

## Components and prerequisites

- Node 22 or newer; tested with Node 24.19.0 and DSH 0.1.5-rc.1.
- `npm ci` in this repository, then `node bin/resonant-voice.js init`.
- Python 3.13 was tested with `workers/requirements.txt`. Prefer a dedicated virtual environment and set `asr.python` to its absolute interpreter path in the configuration. The worker downloads Whisper `small.en` on first use unless a local model directory is configured. The default revision is pinned to the tested small.en snapshot; change `asr.revision` alongside `asr.model` when selecting another model. Keep it resident during a voice connection.
- Native Augmentor requires its existing Qt/websocket dependencies plus `sounddevice` from Augmentor's `requirements-voice.txt` and the system PortAudio library. Browser capture uses AudioWorklet and the browser's microphone permission.
- Compile the external Breeze runtime and obtain its Q4 model separately. Neither models nor external runtime binaries are distributed in the plugin tarball.

Configuration and a private bridge token live in `~/.config/resonant-voice/` (or `RESONANT_VOICE_HOME`). The token is mode 0600. Do not put tokens in command lines, browser URLs, logs or source control. `tts.url` defaults to `http://127.0.0.1:8878`; the companion uses port 8877. Port 8768 was already occupied on the development machine and was left untouched.

## Breeze runtime

The tested source is [HoppouAI/Breeze-TTS-2.cpp](https://github.com/HoppouAI/Breeze-TTS-2.cpp), commit `a5436642d4c64304b398ceeda9b8fce4577bfdb1`, with ggml submodule `36da57138425487184aa1da2eee2cde155909c6f`. Build with CMake, C++17, Vulkan headers/library, `glslc` and SPIR-V headers. On this host, missing Debian build packages were extracted under ignored `outputs/deps/root`; no system package or driver was changed.

```sh
git clone --recursive https://github.com/HoppouAI/Breeze-TTS-2.cpp outputs/runtime/breeze
git -C outputs/runtime/breeze checkout a5436642d4c64304b398ceeda9b8fce4577bfdb1
git -C outputs/runtime/breeze submodule update --init --recursive
cmake -S outputs/runtime/breeze -B outputs/runtime/breeze/build \
  -DCMAKE_BUILD_TYPE=Release -DBREEZE_VULKAN=ON -DBREEZE_CUDA=OFF
cmake --build outputs/runtime/breeze/build -j 4
c++ -std=c++17 bin/vulkan-devices.cpp -lvulkan -o outputs/vulkan-devices
```

The model is `breeze-tts-2-q4_k.gguf`, 2,538,909,376 bytes, from [HoppouAI's model repository](https://huggingface.co/HoppouAI/Breeze-TTS-2.cpp/tree/81b22bad9f05b99970e30c5ee5e4bbc52fedf2f8). The tested model revision is `81b22bad9f05b99970e30c5ee5e4bbc52fedf2f8`. Do not substitute the experimental `dd2` model. Breeze's separate non-commercial model/output terms continue to apply.

Start a **CPU functional check** explicitly:

```sh
python3 bin/launch-breeze.py \
  --runtime outputs/runtime/breeze/build/breeze-server \
  --model models/breeze-tts-2-q4_k.gguf --cpu
```

For a GPU run, replace `--cpu` with `--gpu GPU-<exact-uuid> --probe outputs/vulkan-devices`. The launcher maps the UUID to Vulkan's actual index, checks free memory and the port, and aborts if the runtime falls back to CPU. The default 4,608 MiB free-memory threshold is a conservative admission estimate, **not** a measured peak, reservation or guarantee against another process allocating memory. It never stops another workload or reduces Qwen context. On the development host the mapping is Vulkan 1 = 5090, Vulkan 2 = 5060 Ti; do not hardcode CUDA indices.

The launcher sets a four-frame first audio chunk and a twelve-frame maximum. These worked in the CPU smoke test; GPU latency and prosody still require measurement. WebSocket serving and the upstream WebUI are disabled; only loopback HTTP is used. The upstream HTTP server is unauthenticated, so do not expose it beyond this same-user desktop trust boundary. The companion provides authentication for surface connections.

In another terminal:

```sh
node bin/resonant-voice.js doctor
node bin/resonant-voice.js serve
```

`doctor` checks configuration and Breeze's PCM contract. It does not benchmark the microphone, verify English quality, or claim GPU readiness. It is normal for initial Whisper loading to take longer than a warm utterance.

## DSH and Augmentor

Build the package with `npm pack --pack-destination outputs`. Install the resulting absolute tarball path using:

```sh
dsh plugin --profile web add /absolute/path/dsh-resonant-voice-0.1.16.tgz \
  --ignore-scripts --config.auto-install-peers=false
```

The bundle activates on the next DSH start. Initialize Resonant configuration first; DSH must have Augmentor's existing `augmentor-product-token`. Do not restart an active agent turn just to load the bundle. Removal:

```sh
dsh plugin --profile web remove dsh-resonant-voice \
  --config.ignore-scripts=true --config.auto-install-peers=false
```

The surface changes are in the maintained Augmentor repository, not duplicated in this package: `apps/native/augmentor_linux/voice.py`, its controller/window/DSH adapter wiring, and Chromium `voice.mjs`/`voice-worklet.js` plus the native-host bridge. They need to be deployed with the matching Augmentor build; installing only this tarball does not update an already installed desktop application or extension.

Open an idle DSH conversation, select **Resonant Voice**, wait for Ready, and hold the talk button. Release to submit the finalized transcript once through the existing session. Existing tools and approval controls remain in Augmentor. Use headphones for this preview. A new utterance mutes old speech locally; if DSH is still working, the utterance uses the existing queue and does not cancel completed actions. Task Stop disconnects voice and stops DSH; reopen Voice afterward. Mute affects speech only. Changing conversation closes voice. Reconnection never replays audio or resubmits an uncertain prompt.

## Verification and limits

```sh
npm test
node test/dsh-integration.mjs
npm pack --pack-destination outputs
node test/install-proof.mjs outputs/dsh-resonant-voice-0.1.16.tgz
```

The DSH integration runs the actual installed DSH lifecycle with **fixture LLM and TTS**. The install proof uses a disposable DSH home and may download npm dependencies; it never changes the live profile. Native tests use offscreen Qt and browser tests use simulated browser audio APIs. Those do not replace real microphone, speaker, permission and browser-extension acceptance.

Known preview limits: utterance-based ASR (no partial transcript or neural EOU), browser hands-free is not qualified, and human acoustic echo/double-talk, listening quality and first-meaningful-audio p50/p95 remain separate acceptance work. The guided Linux installer now provides service activation; historical setup instructions above remain useful for manual deployments. CPU TTS is slower than real time. The adapters are separated, but only `faster-whisper` and `breeze-http` are implemented; adding an engine requires implementing and testing the adapter contract. Unknown adapter names fail explicitly.

Single ownership, 15-second one-use tickets, 60-second utterance limits, bounded text/audio queues, reasoning/code filtering, generation invalidation and no audio retention are implemented. A voice connection must be reopened for a new owner; this preview does not renew the plugin's twelve-hour session forwarding lease.


### Explicit placement override

`--allow-low-memory` bypasses only the launcher's conservative free-memory
admission estimate when the operator explicitly requests that experiment. Exact
GPU UUID mapping and rejection of runtime CPU fallback remain enforced. It does
not resize another model or select another GPU. Report an actual failed launch
or synthesis rather than switching placement automatically. The September 19
operator-directed 5090 move uses this flag with unchanged Qwen settings.
