<!-- Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT -->
# Synthetic voice library and playback settings

Historical 0.1.8 library: the current 0.1.14 catalog is `voices/library.json` (Clara, Ava, Zoe, Alice, Emilia, Ben, Daniel, Marcus, Eden and Sage).

Companion 0.1.8 added ten original synthetic female voice candidates: Ava, Clara, Maya, Lily, Nora, Elena, Zoe, Iris, Freya and Sophie. Descriptions in the catalog record intended voice directions, not independently verified accent classifications. The previous voice remains as Original. No real person's voice was cloned.

Each candidate has a fixed seed and its own saved Breeze reference. The preview text is identical across all ten, and each preview was synthesized using the saved reference rather than the original design instruction alone. Names describe choices for user audition, not a claim that every candidate meets the user's subjective preference.

Go to Settings → Resonant Voice. Choose a voice, adjust speaking speed (0.75×–1.50×) and output volume (0–100%), then Play voice sample. Save applies the choices to the next spoken reply. Settings are persisted atomically in the speech host configuration. An in-progress reply retains its original voice and playback parameters. Recording and preview cannot run together; opening the settings page never starts the microphone or submits a prompt.

Playback speed uses streaming FFmpeg `atempo`, preserving pitch rather than changing sample rate. Normal 1.00×/100% live speech bypasses processing. FFmpeg must be available on the speech host's PATH. Previews are saved local clips and do not require a new GPU generation. They are played at the unsaved speed/volume currently shown in the settings page.

The source/package includes `voices/library.json`, saved `.breeze` references and synthetic WAV audition clips. Microphone recordings and model weights are excluded. For a new deployment copy these into the configured `voiceLibrary` directory, preserving custom voices, and point Breeze's `--voices-dir` at that directory before starting it. On this machine references were added through Breeze's API and are already loaded; no Breeze restart was required. The one-time design script records candidate prompts and seeds for reproducibility.

All ten preview transcripts matched the common script after punctuation normalization, and none contained clipped samples. This is intelligibility/signal verification, not a substitute for choosing by ear. The preview text is: “Let us take a moment to find the right approach. I can help you think it through, then we can choose what to do next.”

## Local settings contract

The authenticated loopback bridge accepts POST `/internal/preferences` with `{}` to read voice names, descriptions and values; `{values:{voiceId,speed,volume}}` validates and saves them. POST `/internal/preview` with those playback values returns mono s16le PCM at 24 kHz. Both endpoints use the existing private `x-resonant-token` header and reject browser-origin requests. Clients never receive local catalog paths or the token in the response.
