<!-- Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT -->
# Native test deployment · updated 19 September 2026

Current source package: **0.1.14**. The native preview supports hold/release,
slide-left to lock, slide-right for temporary hands-free, saved voice/speed/volume
per window, and the CPU VAD / PipeWire echo-cancellation path. Clara is the default.
See the repository README and hands-free documents for current behavior.

The sections below are a chronological deployment record. Earlier version,
popup, push-to-talk-only and committed-message-only descriptions are historical;
they do not describe the final snapshot. No new speech-model/GPU service was
reconfigured during the September memory/GitHub publication work.

## Initial deployment record

Current state: native inline controls, website orb, DSH streamed clauses, saved female reference, and plugin activation restored. [18 September audit](AUDIT-2026-09-18.md) supersedes the older popup, committed-message-only and timing notes below.

Installed plugin: 0.1.6 in the DSH web profile. Qwen on the RTX 5090 is unchanged. The user authorized stopping the secondary Qwen service on the RTX 5060 Ti; `gpu-llm-5060ti.service` is stopped and disabled (it was already disabled). Breeze Q4_K now runs there. ASR uses resident CPU Whisper small.en/int8. Providers remain configurable.

Click the robot beside Send in Augmentor, or the **Resonant Voice** desktop shortcut. Hold **Hold to talk**, speak English, then release. The transcript enters the existing DSH conversation; replies appear as text and play aloud. This preview is push-to-talk, not hands-free. The native surface forwards committed assistant text, excluding reasoning, to streaming speech; it does not yet speak partial assistant text. Stop and mute remain available.

## Installation

- Enabled user services: `resonant-breeze.service`, `resonant-voice.service`, loopback ports 8878 and 8877.
- Breeze runtime, libraries and model: `~/.local/share/resonant-voice/breeze/`; GPU UUID is checked against Vulkan enumeration before launch. Startup warmup discards one synthesis to compile shaders.
- Private configuration/token: `~/.config/resonant-voice/`.
- Native test app: user-local snapshot of installed Augmentor 0.2.8 at `~/.local/share/resonant-voice/augmentor-preview`, with focused voice and model-restoration changes. The root-owned installed package is unchanged. Maintained source changes are also in the sibling Augmentor repository.
- Launcher: `~/.local/bin/augmentor-voice-preview`, with a Python 3.13 audio environment and native Wayland override. XWayland launch exited prematurely on this desktop; native Wayland remained running with the authenticated ASR connection ready.
- Desktop entry: `~/.local/share/applications/com.augmentor.ResonantVoice.desktop`, also copied to `~/Desktop/Resonant Voice.desktop`. The normal user-local Augmentor entry points to the same preview, preserving single-instance routing.

## Measured evidence and limits

| Check | Measured result |
| --- | --- |
| 5090 free memory at final check | 2,413 MiB; insufficient even for observed Breeze allocation without changing other workloads |
| 5060 Ti final memory used/free | 2,973 / 12,876 MiB (whole-card snapshot) |
| Warm Breeze first PCM | 0.243 seconds |
| Warm Breeze total | 1.313 seconds for 3.36 seconds of audio |
| Cold shader synthesis first PCM | 5.817 seconds, before startup warmup |
| CPU recognition synthetic sample | 0.719 seconds |
| Warm synthetic ASR → real DSH/Qwen → speech | 2.025 seconds from end of supplied audio to first PCM |
| Earlier cold/contended full pipeline | 41.237 seconds |

Full-pipeline evidence is under ignored `outputs/deployment/`; the JSON records the warm repeat. Native delivery was also checked using a real DSH reply and companion surface-reply diagnostics. These checks prove routing and audio generation, not the user's physical microphone, speaker audibility or subjective quality. Latency depends on conversation prefill, Qwen contention and answer length; no zero-delay claim is made.

## Deployment incident

A shell continued after a busy-session guard failed and restarted DSH, interrupting “Analyze my latest think out.” This was disclosed during deployment. No task was replayed or resubmitted by this deployment. Subsequent package updates required only the speech companion restart; no additional DSH restart was performed.

## Rollback

Close the idle voice window, then stop and disable the two Resonant user services. Restore the normal Augmentor desktop entry from `outputs/deployment/augmentor-desktop-before.desktop`, and remove the Resonant desktop entries if desired. Start `gpu-llm-5060ti.service` only after Breeze has fully stopped; retain its original disabled-at-login setting. The original system Augmentor launcher remains `/usr/bin/augmentor-agent`. Removing the DSH bundle requires a later idle-host restart to unload it; never restart DSH during an active task. Model, history and configuration files are preserved.

## Playback and desktop correction · 0.1.3

Settings now has a persistent Resonant Voice checkbox. Disabling it closes capture/playback and the session connection, hides the robot, and prevents shortcut/ticket completion from reopening speech. Shared local speech services remain resident for quick re-enabling; this toggle controls participation in Augmentor, not global GPU service allocation.

Breeze uses saved synthetic reference `resonant-warm-female`, generated with a warm adult female direction and seed 42. The six-second WAV and encoded voice are in `~/.local/share/resonant-voice/voices`. The runtime explicitly loads that folder at startup. Every synthesis request uses this voice ID and seed; identity is anchored by the reference, not the seed alone. Subjective voice quality still needs listening acceptance.

Audio is now paced across synthesis requests to stay approximately half a second ahead of normal playback, rather than overflowing the native eight-second cap. Long multi-part regression tests verify complete delivery. Under native Wayland the halo is a child of the main window, so it cannot drift to an independently compositor-chosen position. Wayland clips the exterior effect to the window's transparent margin; X11 retains the extended exterior halo.

Only the voice services and the idle desktop were restarted for this correction; DSH was not restarted.

Live 0.1.3 speech regression: four segments, 16.4 seconds of PCM, first PCM 0.348 seconds, maximum simulated normal-playback backlog 0.601 seconds. This measures TTS and transport, not ASR/LLM latency or physical listening. Evidence: `outputs/deployment/long-reply.json` and `.pcm`. Nine service tests and eight native voice/UI tests passed.

## Restore original exterior effects

At the user's request, the original `HaloCanvas` implementation was retrieved from GitHub tag `v0.2.9-recovery.1` in ManoloRemiddi/augmentor-agent and restored in both maintained source and the installed preview. The voice launcher's forced native-Wayland override was removed, returning to the repository launcher’s XWayland (`xcb`) behavior. The temporary child-canvas clipping workaround is removed. Existing local effect choices and voice controls remain intact.

The idle desktop closed through its maintenance protocol and relaunched successfully. Its process environment confirms `QT_QPA_PLATFORM=xcb`; the desktop reports modelReady. Eight native tests pass, including exterior halo geometry following a moved window while retaining the full exterior extent. No DSH or model service restart was needed. This supersedes the earlier native-Wayland and clipped-margin deployment notes.

## Conversational mode and interruption fixes · 0.1.4

Reviewed the user's latest native session `augmentor-linux-product-6dba6c9aa2cd4aab8f8038b12c1cb095`. All five user turns completed in DSH. Text answers included 342, 336, 525 and 1,789 words. The final transcript read “Okay, give me a too long detail red answer please.” The original audio is not retained, so its intended wording cannot be reconstructed. No voice-specific instruction was present in those turns.

The plugin incorrectly treated `agent/turn-stopping` as cancellation. In installed DSH 0.1.5-rc.1 that hook runs during successful completion too; it was removed. Genuine stream cancellation, surface Stop, close, mute and push-to-talk interruption retain audio invalidation. Runtime busy (409) immediately after interrupted synthesis is retried for up to ten seconds, only before any audio is accepted, and remains abortable. Recoverable synthesis errors no longer permanently disable the microphone.

Native recorded messages now carry a `resonant-voice:` request ID. The DSH plugin adds a per-request model-context instruction via its supported pre-step hook: normally one to three short sentences, about 60 words or fewer, no exhaustive lists, and brief clarification of garbled requests. This is an additional plugin context message; the base system prompt, reasoning setting and tools are not replaced. Typed requests explicitly reset voice-only style. Spoken follow-ups use DSH steering when a turn is active, and playback waits for the matching request to be claimed. Steering applies at DSH's next available step boundary; it does not promise immediate cancellation of a running tool. The microphone remains push-to-talk, not always listening.

Validation includes real DSH lifecycle with fixture model/speech, normal completion without audio cancellation, voice instruction and typed reset, multi-part pacing, interrupted playback followed by a new reply on the same connection, busy retry/abort, and native request gating/microphone recovery. Eleven service tests and nine native tests passed. DSH was reloaded only after checking all sessions idle; the idle desktop closed through its maintenance protocol. GPU placement, reference voice and restored exterior effects were preserved.

Live 0.1.4 checks: the same capabilities question produced a 50-word answer with the voice instruction confirmed in DSH history (9.11 seconds for the model turn). Real Breeze interruption stopped the old stream after 15,360 bytes; the immediately following synthesis completed with 2.16 seconds of audio in 1.10 seconds. These are separate model and synthesis checks, not a microphone-to-speaker end-to-end latency claim. Evidence: `outputs/deployment/voice-style.json` and `live-interruption.json`.


## 19 September: 10-minute capture and native slide-to-lock

Speech companion 0.1.7 is deployed at `~/.local/share/resonant-voice/releases/0.1.7/package` from the versioned tarball. It includes the existing pinned ws 8.21.3 dependency. A user-service override selects this release. The DSH profile still has plugin entry point 0.1.6, which is byte-identical to 0.1.7; its manifest, lockfile and running process were not changed. An offline package-manager staging attempt needed uncached metadata, so deployment used the independent companion release instead of re-resolving DSH dependencies.

Configuration and both ASR/service limits are now 600 seconds. The recognizer's live process arguments confirm `--max-seconds 600`. The service advertises the limit and auto-finalizes at the byte budget or wall-clock deadline, preserving audio for transcription. Native capture also stops at its negotiated limit.

The native user-local desktop has slide-left locking, click-to-finish, Escape-to-cancel, an audio-reactive waveform and elapsed-time tooltips. Orange begins with two minutes remaining; red begins with one minute remaining. The outer recording indicator animates independently of the audio meter. Locked recording continues across focus changes; explicit hide, conversation change and disabling voice cancel it.

Validation: 297 native tests, 15 service tests and the Python worker retention test passed. Service tests send a full 600-second PCM budget at accelerated speed and verify no truncation, one finalization, harmless late packets and a successful next utterance. The real Whisper worker received a synthetic ten-minute buffer with two spoken markers separated by silence and recovered both beginning/end markers. Its 1.18-second transcription time reflects mostly silence and is not a benchmark for continuous ten-minute speech. The running native app was observed in Locked state with live service capture active after mouse release; that user recording was left untouched.

Only focused native files were applied to the existing 0.2.8 preview, preserving the separate 0.2.9 source tree. Backup: `~/.local/share/resonant-voice/backups/long-lock-20260919-095141`. Draft contents were preserved. A stale KDE shortcut copy still invoked the system application and raced the first reopen; its Exec entry now matches the user-local preview launcher, and the desktop launcher cache was refreshed. The running application was verified to import the updated preview, not `/usr/lib/augmentor`. Breeze and DSH services were not restarted, and GPU/model settings were unchanged.


## 19 September: female voice library and settings (companion 0.1.8)

Ten original synthetic voice references and common-text previews were created and registered with the running Breeze instance: Ava, Clara, Maya, Lily, Nora, Elena, Zoe, Iris, Freya and Sophie. Original remains available as the previous voice. The catalog and encoded references/previews are included in the 0.1.8 artifact and installed under the existing voice-library directory. All ten previews passed script transcription, non-silence and clipping checks; subjective voice/accent preference remains for listening acceptance.

The dedicated Resonant Voice settings page offers voice selection, preview/stop, 0.75×–1.50× pitch-preserving speaking speed, output volume, enable/disable and recording guidance. Settings navigation now uses theme-coloured SVG icons. Save persists playback choices atomically; a reply snapshots voice/speed/volume so settings changes cannot switch voice between its chunks. Normal 1.00×/100% speech bypasses audio processing. Other rates/volumes use the installed FFmpeg binary; previews use saved audio and do not require GPU synthesis.

Companion release 0.1.8 is selected by the existing service override. DSH's unchanged plugin entry point remains installed as 0.1.6; DSH and Breeze were not restarted. Only the SettingsDialog section of native panels.py, two new settings modules and SVG assets were installed into the existing preview. Recording UI and its 10-minute/lock behavior were preserved. Backup: `~/.local/share/resonant-voice/backups/voice-settings-20260919-101453`.

Validation: 300 native tests and 19 service tests pass. A generated sine-wave test checks that speed alters duration without shifting pitch and that volume reduces amplitude. Live authenticated endpoints list all eleven choices, return a 5.35-second Ava preview at 1.20×, and persist unchanged preferences without selecting a different voice. The new settings page was opened in the installed desktop and its controls/catalog verified through accessibility. Offscreen visual inspection confirmed the settings layout and SVG icons. Existing draft contents were restored during the idle desktop restart.


## User-directed RTX 5090 placement — 19 September 2026

The user explicitly requires Breeze on the RTX 5090 alongside Qwen and directs
that Qwen context size remain unchanged for this attempt. The old 5060 Ti fallback
is superseded. A failure must be reported, with no automatic move back, context
reduction, change of precision/concurrency, or eviction of other workloads.
ASR/VAD remain the existing CPU path; this change moves GPU speech synthesis.

The launcher adds an explicit `--allow-low-memory` override of its admission
estimate, retaining exact NVIDIA UUID → Vulkan device matching and CPU-fallback
rejection. Three launcher tests cover default refusal, the requested override
with the exact GPU, and continued rejection of CPU fallback. No speech protocol,
voice reference or model artifact changes. The launcher is installed as a
standalone hash-versioned file from the published source; the running speech
companion/plugin remains 0.1.14. The service is pinned to the 5090 UUID and does
not select another GPU on failure.

Before moving the service, preserve its unit and Qwen unit/drop-in checksums.
Restart only Breeze after checking native capture and model work are idle; do
not restart Qwen, DSH or change the native UI. Record actual load/synthesis and
GPU residency results below; estimates alone do not qualify the placement.


Actual result: published launcher source `af9e2f0` loaded Breeze on the RTX 5090
(Vulkan device mapping 1) and completed startup warmup. NVIDIA process accounting
shows Qwen at 28,038 MiB and Breeze at 2,695 MiB on the 5090; the 5060 Ti has no
Breeze process. One post-load snapshot had 832 MiB free on the 5090. This is a
snapshot, not a guaranteed peak-memory margin. Qwen's PID and service/drop-in
hashes match the pre-change snapshot exactly; its context and concurrency were
not adjusted. Only Breeze was restarted; the native app and DSH stayed running.

A warm synthesis using the saved Clara voice produced its first PCM in 299 ms
and generated 4.875 seconds of audio in 5.638 seconds with concurrent Qwen load.
The audio was discarded rather than played into the user's microphone. This
proves successful synthesis and GPU placement, not faster full conversations or
continuous playback under every load. The service remained active with zero
automatic restarts. Keep this user-requested 5090 placement; report any subsequent
failure and ask the user to choose the next change. No automatic fallback is
configured. CPU transcription/VAD are unchanged.

## 20 September 2026: incremental ASR 0.1.16

Source implementation: `fbb7cd3`. Installed companion package:
`~/.local/share/resonant-voice/releases/0.1.16/package`, staged separately from
0.1.14. Packed artifact SHA-256:
`775de1767c1df5dff4b463b37a997cb091ec399e0e663a6679a4683ce1b1af14`.
The exact locked ws 8.21.3 dependency was preserved. The companion's runtime
systemd drop-in selects the new package; the prior file is retained as
`runtime.conf.before-0.1.16`. Only the idle voice companion was restarted, after
two health checks confirmed it had no owner. Qwen, Breeze, DSH, memory and desktop
processes were not restarted or reconfigured. The installed DSH voice plugin
remains 0.1.14: its plugin source is byte-identical to the new package and its
protocol is compatible. A future complete installation pins all voice components
to 0.1.16; this live patch deliberately avoids interrupting DSH work.

Live installed verification connected through the authenticated WebSocket, sent
synthetic 8.32-second PCM at speaking speed, received three provisional transcripts
before end-input and exactly one final (938 ms after end). It submitted zero DSH
prompts, played no audio and closed its test owner. Tokens/transcripts were not
logged. This tests the actual installed launcher/worker/service path; it does not
claim a human microphone/speaker trial.

The native counterpart is source `8f9903d` on Augmentor's development branch.
Its separately staged 0.2.8-compatible artifact is selected for subsequent launches;
existing windows became busy and correctly refused maintenance close. Their native
playback fix remains pending until a safe close/reopen or login. Incremental ASR
already applies when they next connect to the updated companion.

Rollback: after checking that voice has no active owner, restore the saved runtime
configuration over `runtime.conf`, run `systemctl --user daemon-reload`, then restart
`resonant-voice.service`. That restores 0.1.14 batch recognition. Native selection
rollback is independent through `augmentor-update rollback`; neither action changes
user conversations, models or GPU settings. See [incremental recognition](INCREMENTAL-ASR.md)
for timing evidence, limits and the unchanged remaining agent-response latency.

### Subsequent user-requested desktop restart

The user requested activation in all open windows. Desktop, secondary and mobile
were closed gracefully after idle/draft checks and restarted through their managed
launchers. All three reconnected on native release `20260920-150518-3d939dd3` with
no pending update; saved conversations and selected models were preserved. The
0.1.16 companion and the DSH/model services were not restarted. This supersedes
the pending-native status above. First-word acoustic acceptance remains a user
trial; see Augmentor's desktop deployment guide for verification details.
