<!-- Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT -->
# Structured speech 0.1.10

Opt-in configuration: `expressiveSpeech: true`. Default is off. Disable this flag and restart DSH and the companion to restore ordinary text streaming. The selected voice, volume and base speed remain authoritative.

DSH 0.1.5-rc.1 has no response-format request field. Its supported terminal tool contract is used instead: `resonant_voice_reply({text,speech:{emotion,speedMultiplier}})`. `concludeTurn()` avoids a second LLM request. This waits for the complete short tool response before synthesis, unlike the earlier first-clause text stream. Do not claim equal end-to-end latency without conversational measurements. Ordinary text remains a neutral fallback. Emphasis is not implemented.

The response metadata is validated, tied to the claimed user request, deduplicated by call ID, and copied into each synthesis queue item. Interrupt/capture invalidates stale responses. Relative speed is limited to 0.85–1.15, combined with the user's base speed, then clamped to 0.75–1.50. Breeze receives a fixed instruction for each enum and the same saved reference and seed. Emotion is a model instruction, not an acoustically guaranteed outcome.

The terminal tool returns replayable `meta.resonantVoice` with version 1, text and speech fields. Augmentor renders that text as an assistant reply. DSH's native tool result remains the durable source. Unsupported clients see the text in a tool result. Native tool mode is required; PTC sub-dispatch presentation is not supported in this iteration.

Qualification: 22 companion tests and 301 native tests passed. DSH's actual tool runtime returned `concludesTurn:true` and the expected presentation metadata. One standalone local Qwen probe returned the correct structured tool arguments in approximately 1.0 seconds; this is not an end-to-end conversation benchmark or a percentile measurement. Listening qualification remains necessary for perceived emotion and Clara identity.

Voice cleanup: Clara, Ava, Zoe, Alice, Emilia, Ben, Daniel, Marcus, Eden and Sage remain. Removed names include Sophie (requested as sofy) and the original warm female voice. Historical release archives are retained for rollback; removed voices are absent from the active catalog and Breeze cache.
