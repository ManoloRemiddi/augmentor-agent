<!-- Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT -->
# Incremental ASR and voice latency — 20 September 2026

## Confirmed problem and changes in 0.1.16

The previous worker streamed microphone packets into memory but called Whisper
only after `end`. It was utterance-batched recognition. The new worker starts a
CPU inference pass after each two seconds of new audio while capture continues.
Only one inference runs at a time; input ingestion remains independent. Two
successive hypotheses must agree before an older word becomes stable. Provisional
text can change; only one final transcript reaches the existing DSH submit path.

The decoder retains acoustic context and trims at completed sentence boundaries,
keeping at least six seconds of audio and two seconds before the committed word
boundary. Timestamp-aware suffix matching removes overlap without removing an
intentional repeated word starting after the committed boundary. At 30 seconds
without a suitable sentence boundary, older words are committed with a two-second
lookahead; silence also advances. A pathological window that cannot advance fails
without submitting an incomplete result. Individual inference windows are capped
at 30 seconds and the cumulative recording limit remains 600 seconds. EOF before
`end` cancels recognition. Raw audio and partials remain ephemeral.

The CPU small.en/int8 model, six threads, one worker, revision, beam size, VAD,
vocabulary hint and temperature fallback policy are unchanged. Word timestamps
are enabled for boundary reconciliation. Qwen and Breeze remain on the user's
RTX 5090 with unchanged model/context/concurrency/precision. A high utilization
percentage alone is not evidence of a fault or reason to reduce GPU use.

## Measured evidence and limitations

Synthetic audio was replayed through the actual worker in 20 ms packets at real
speaking speed. No microphone recording or user DSH turn was created. Word equality
below ignores punctuation/capitalization and compares against the prior batch
settings on exactly the same PCM; it is not a general accuracy guarantee.

| Input | First provisional text | Finalization after release | Batch decode | Same words |
| --- | --- | --- | --- | --- |
| 8.32 s Clara reference | 2.48 s | 895 ms | 598 ms | yes |
| 14.28 s newly generated ordinary instructions | 2.40 s | 974 ms | 791 ms | yes |
| 26.46 s repeated reference with pauses, two runs | 2.47–2.56 s | 624–873 ms | 8,285–10,630 ms | yes |

The repeated fixture exercises overlap but is not representative of every spoken
request. Short requests can pay an outstanding pass plus a tail pass; incremental
recognition does not guarantee faster finalization for every utterance. It does
make recognition happen during speech, and avoids deferring all long-recording
work until release. Initial narrow context trimming was rejected after real-model
tests found duplicated words and 8–13 second decodes; the published implementation
retains sentence context. Human microphone accuracy/noise and conversational
latency still need a user trial.

Reproduce with `python3 test/asr-streaming-check.py /absolute/synthetic.wav` and
optionally `--repeat 3`. The script reports timings and word equality without
printing or saving transcripts. CPU dependencies and the pinned model must be
installed. The default fixture is not bundled by this script; use a synthetic
reference from the installed voice library or generate an ordinary test passage.

Source checks: eight Python ASR tests pass (real subprocess with stub inference,
including partial-before-end, corrections, repeated words, silence, full 600-second
coverage with bounded windows, cumulative limit and hint precedence). All 34 Node
tests pass, including provisional/final routing and stale utterance rejection.
Actual DSH 0.1.5-rc.1 lifecycle integration and disposable tarball install/remove
also pass with fixture LLM/TTS. These do not establish physical acoustic quality.

## Other pipeline stages

A real Breeze/tempo output trace produced 142 ms of initial audio at 220 ms, then
its next output at 463 ms. Playing immediately leaves a 101 ms opening gap. The
Augmentor native change adds a 200 ms reserve with a 250 ms maximum initial wait,
short-response draining and immediate interruption. It keeps the device callback
alive; that is distinct from proving an audio-device connection fault.

In an observed short live turn, the agent took 15.21 seconds before the speech tool,
with first model output after 9.50 seconds; Breeze itself commonly produced first
audio in 200–210 ms. Other longer diagnostic turns included tools and additional
reasoning and are not comparable greeting benchmarks. Expressive speech waits for
model-authored speech passages; provisional ordinary prose cannot be played twice.
Background memory requests can compete for model service, but a GPU utilization
snapshot does not establish how much of a particular delay they caused. No
reasoning, memory, placement or model policy was reduced to improve these tests.

Native maintenance status exposes numeric ASR progress/finalization, first PCM,
first device callback, buffer starvation and device underflow counters. The first
callback timing is not measured acoustic onset. Use these separate stages for the
next live trial before assigning all waiting time to GPU load.
