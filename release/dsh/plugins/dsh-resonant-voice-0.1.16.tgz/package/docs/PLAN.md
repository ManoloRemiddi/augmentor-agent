<!-- Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT -->

# Resonant Voice architecture and delivery plan

**Current placement instruction (19 September):** the user requires Breeze on
the RTX 5090 alongside Qwen, with Qwen context unchanged. The earlier admission
and fallback plan below is historical design rationale. The operator-directed
move succeeded; see [current deployment evidence](DEPLOYMENT.md#user-directed-rtx-5090-placement--19-september-2026).
Do not change placement or context without notifying the user and receiving their
direction, including after a failure.


Revision: 18 September 2026. [Audit and current implementation gaps](AUDIT-2026-09-18.md) supersede preview status claims. Implementation preview now exists; see RUNNING.md for implemented scope and remaining qualification. Supersedes the deployment/model recommendations and latency targets in Augmentor's 14 September `VOICE-PLUGIN-PLAN.md`; its video analysis remains historical context.

## Decisions and open qualification

The user selected English, Breeze-TTS-2, retention of the current Qwen model, replaceable speech models, and a preference for using only the 5090 if it causes no problems. Use the 5060 Ti when separation is needed. Speed must preserve voice and task quality. No claim that Breeze is independently verified as the best model is required to honor that selection.

Prefer single-5090 inference only after passing memory, latency, quality and existing-workload checks. Test smaller Breeze Q4_K and INT4 implementations first: [quantization research](QUANTIZATION.md) found materially smaller packages than the original audio.cpp Q8 baseline. Current free VRAM still does not establish a safe fit once runtime, ASR and headroom are included. Right-sizing Qwen's context allocation is a second capacity experiment, not an already approved live configuration change. If the required context/concurrency and quality cannot coexist with speech, test split GPUs after freeing the speech card.

Literal zero delay is not achievable with endpoint detection, model inference and audio playback. The product goal is imperceptible or acceptably short delay in ordinary conversation, measured with the user. Neither cached filler nor faster-than-real-time TTS establishes that result. The old 2–3 second target is no longer the desired final experience.

## Ownership and packaging

Resonant Voice is a standalone repository for a distributable DSH plugin and local speech companion. Proposed future components are:

| Component | Owner and responsibility |
| --- | --- |
| DSH plugin (`dsh-resonant-voice`, proposed) | Session/preset opt-in, assistant text/status hooks, connection to voice service, capability reporting |
| Voice service | Audio-session state, bounded queues, endpoint policy, workers, device placement, health and cancellation |
| ASR adapter | Incremental PCM input, partial/final transcript revisions, optional end-of-utterance signal |
| TTS adapter | Bounded text segments, fixed voice settings, streaming PCM, cancellation and timing |
| Contract package | Versioned session/turn/generation IDs, sequence numbers, audio format, errors and capabilities |
| Augmentor integrations | Existing Qt and Chromium repositories/surfaces own microphone permission, capture, playback, controls and task display |

The interface must distinguish incremental audio output from incremental text input: a backend that streams audio may still require a complete input segment. Capability negotiation includes that distinction, model/runtime revision, device, cancellation support, languages and native sample format. Select adapters at configuration time; never swap models or move GPUs silently during a reply.

Distribute pinned contracts and installable artifacts. Do not import sibling checkout files at runtime, copy the Augmentor UI, or put CUDA inference in the DSH event loop. Use the supported DSH bundle pattern; 0.1.5-rc.1 was the prior integration baseline and needs fresh qualification before release. No Resonant CORE dependency is introduced.

```mermaid
flowchart LR
    Mic[Augmentor microphone] --> Front[CPU audio processing and speech detection]
    Front --> ASR[Streaming ASR adapter]
    ASR --> Commit[Finalize utterance once]
    Commit --> DSH[Existing DSH session]
    DSH <--> Qwen[Existing Qwen on 5090]
    DSH <--> Tools[Existing surface-scoped tools]
    DSH --> Text[Assistant text and status events]
    Text --> Chunk[Short coherent text segments]
    Chunk --> TTS[Breeze adapter]
    TTS --> Audio[Incremental PCM playback]
```

ASR/TTS placement is independent of these contracts. DSH retains model choice, native history, memory, tool execution and approvals. The plugin never starts a second conversational LLM to disguise latency.

## Placement decision

| Profile | 5090 | 5060 Ti | When to choose |
| --- | --- | --- | --- |
| A: preferred single GPU | Qwen + qualified Breeze quantization + streaming ASR | Unchanged | Test compact TTS first; reduce an agreed LLM reservation only if needed, with measured headroom and no unacceptable contention |
| B: split speech | Qwen with current context/concurrency | Qualified Breeze + ASR | Fallback when A cannot preserve requirements or fails latency; requires freeing current 5060 workload |
| C: split ASR | Qwen + qualified Breeze | ASR | Diagnostic middle option if TTS fits on 5090 and only ASR contention breaks the budget |

CPU handles capture, resampling, echo cancellation, VAD and playback control. A CPU ASR profile can be tested if useful. Per-frame CPU offloading of Qwen or Breeze is not the default speed strategy; a compact Breeze runtime's one-time-per-request embedding lookup offload is a separate candidate to measure. GPU memory is not pooled. Separating models across cards normally exchanges small text/audio payloads through host memory, not their weights or hidden states; local transport must be measured, but does not justify assuming the single-card profile is faster.

The current 5090 Qwen server uses 524,288 total context tokens with two slots, q4_0 K/V cache, Flash Attention and MTP. Try an agreed reservation of 262,144 total with two slots, then 131,072 total with two slots if necessary. Those reduce per-slot context under the current equal-slot configuration; exact effective capacity must be checked against the installed server. Alternatively test a single voice slot with an agreed context, explicitly losing concurrent service capacity. Never relabel a reduced route as the existing 262k-per-slot route.

Measure cache allocation before projecting savings. Model file size subtracted from process memory is not a valid measurement of KV cache. Hybrid-model state, MTP buffers, compute graphs, image processing and allocator overhead matter. q4_0 cache, Flash Attention and MTP are already enabled, so they are not new optimizations. Fewer actual prompt tokens can improve latency; simply lowering the configured ceiling primarily changes capacity and allocation.

## Speech engines

**Selected TTS: Breeze-TTS-2.** First compare HoppouAI Q4_K/Q6_K with that runtime's Q8 reference and audio.cpp Q8; include the compact CUDA INT4 implementation if its loader, streaming and English quality qualify. CrispASR Q4_K is another small candidate requiring its codec companion and serving audit. The already available official PyTorch runtime is a quality reference, not automatically the selected serving engine. See [the quantization matrix](QUANTIZATION.md). Keep one fixed voice configuration and cache reusable reference conditioning where supported. Models remain loaded while voice mode is active; perform bounded preparation when the user enters voice mode, not a reload per utterance. Record cold start separately.

The [audio.cpp documentation](https://github.com/0xShug0/audio.cpp/blob/main/docs/models/breeze_tts.md) exposes streaming frame size, lookahead and reference caching. Compare smaller audio chunks against defaults and check boundary quality, overhead and underruns. Streaming PCM output does not establish persistent incremental-text support; use coherent text segments unless that capability is proved. HoppouAI documents persistent text/PCM streaming with flush and cancellation; qualify its buffering separately. Q4 is now a first-stage experiment, still subject to English quality acceptance. Avoid experimental depth-decoder variants with reported long-output drift as the default.

The official [Breeze model card](https://huggingface.co/BreezeBlue/Breeze-TTS-2) reports approximately 7.7 GiB for eager inference and 14.4 GiB for the full fast path. Its H100 timing does not predict either desktop GPU. Benchmark selective fast components if useful; the full fast path is not assumed feasible alongside Qwen or on the 16 GB card with ASR/headroom. Model weights and self-hosted outputs retain their separate non-commercial terms; no weights are distributed in this repository.

**Improved ASR shortlist:** test [Parakeet Realtime EOU 120M](https://huggingface.co/nvidia/parakeet_realtime_eou_120m-v1) first for compact English streaming and end-of-utterance signaling. Its lack of punctuation/capitalization matters for dictation but may be acceptable for conversation. Compare [Nemotron Speech Streaming English 0.6B](https://huggingface.co/nvidia/nemotron-speech-streaming-en-0.6b) for recognition quality and configurable streaming chunks. Keep faster-whisper small.en as a known baseline. Select only after accent, technical-name and command tests; a smaller model is not automatically better.

This replaces the assumption that periodically retranscribing Whisper windows is the preferred final design. Do not conflate an ASR chunk duration, an EOU token or a model-card benchmark with end-to-end answer latency.

## Reducing conversational delay

1. **Finish recognition during speech.** Process incremental chunks, retain state and expose partial revisions. Finalization reconciles the tail; only a committed utterance is submitted to DSH. Silence or a revised partial must not execute tools.
2. **Replace the fixed one-second pause.** Test model EOU plus a short tunable VAD guard, initially exploring 150–350 ms. This is a tuning range, not a promise that every speaker should use it. Keep push-to-talk release as an explicit endpoint and a longer-pause option. Measure premature interruptions, not just speed.
3. **Reduce first spoken-text delay.** Ask for a short meaningful opening clause, preserving answer correctness and existing Adaptive Reasoning. Flush at a coherent clause/phrase boundary with a bounded wait; do not wait for a long sentence or full answer. Avoid tiny isolated words that damage prosody.
4. **Stream and buffer only what is needed.** Start playback from the first usable PCM chunk; use a short jitter buffer and bounded lookahead, adjusted by measured underruns. Keep one speech stream per owner. Generate the next phrase while the current one plays without queuing a long obsolete answer.
5. **Protect model responsiveness.** Keep reusable prompt prefixes stable, tool results bounded and relevant, and existing prompt-cache reuse working. Test long-context and second-chat contention. Do not strip necessary history or disable reasoning globally to hit a headline number.
6. **Make turn-taking local and immediate.** Confirmed user speech stops local playback and invalidates old TTS generations before waiting for the transcript or DSH cancellation. Qualified echo cancellation prevents the assistant hearing itself. Headset mode is the first proof; speakers require their own acceptance run.

Speculative tool execution from partial speech is excluded. Speculative LLM work before a confirmed endpoint is deferred: it complicates DSH history/cancellation, wastes compute and can worsen contention. Lower-risk gains should be measured first.

## Behavioral invariants

- One capture/playback owner across Qt and Chromium. Authenticated local streams are scoped to the initiating surface, native DSH session, turn and generation. Use sequence numbers, bounded input sizes and explicit PCM sample formats.
- Separate control from continuous audio transport. Qt uses its native audio path; browser uses its supported audio path with explicit MV3 lifecycle handling. Avoid repeated base64/WAV-file conversions on the hot path.
- Never speak reasoning, tool arguments, raw HTML or code blocks. Detailed reports remain visible as artifacts; spoken summaries cannot omit requested deliverables.
- Audio mute, correction/steering and task Stop have distinct semantics. Reuse DSH steering at safe tool boundaries; Stop clears pending work. A cancelled reply does not undo completed actions. Unknown outcomes are never replayed.
- Reconnection reconciles text history and playback position without resubmission or replaying stale speech. An interrupted spoken reply must not imply the entire generated answer was heard.
- Approvals and questions retain the current UI/authority path. Voice introduces no new permissions. Browser tasks and desktop tasks retain their surface-scoped tools; combined workflows need a separate explicit contract.
- Raw microphone audio is ephemeral by default. Text uses DSH's existing retention. Worker failure leaves text chat available. New engines require protocol/version qualification, not a UI rewrite.
- Progress speech reflects real state and yields to substantive output. Cached acknowledgments remain separately identified and never count as task results.

## Delivery sequence

1. **Qualification before implementation:** measure resource budgets and model/audio latency with agreed temporary profiles; identify consumers of both GPU services. Preserve service definitions, selected routes and session data for rollback. The implementation turn ran CPU functional benchmarks without changing either GPU workload. GPU experiments still depend on the placement decision.
2. **Minimal DSH integration:** plugin, companion, native push-to-talk, partial preview, committed input, Breeze streaming, mute/Stop and failure recovery. Keep models resident during a voice session.
3. **Natural interaction:** qualified streaming ASR/EOU, clause buffering, interruption, echo cancellation and reasoning-policy coordination. Pass simple conversation latency and user listening tests.
4. **Browser parity:** microphone/playback, exclusive ownership, controls and actual tool workflows. Native and browser require separate UI acceptance evidence.
5. **Release:** pin tested runtimes/models/contracts, package plugin and companion separately, document supported placement, install/uninstall, lifecycle and privacy controls. Rich work panels and a live canvas follow reliable voice.

The current repository implements the first push-to-talk path, with CPU ASR, Breeze HTTP streaming and native/browser controls. It does not yet implement the complete natural-interaction design above. [Qualification](QUALIFICATION.md) defines the experiments and records what is and is not known.
