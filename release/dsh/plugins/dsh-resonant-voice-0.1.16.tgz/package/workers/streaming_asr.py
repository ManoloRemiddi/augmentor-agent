# Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT
"""Bounded local-agreement decoding; provisional text is never an agent message."""
from dataclasses import dataclass
import re

RATE = 16000
BYTES_PER_SECOND = RATE * 2
STEP_BYTES = 2 * BYTES_PER_SECOND
WINDOW_BYTES = 30 * BYTES_PER_SECOND
OVERLAP_SECONDS = 2.0


@dataclass
class Word:
    text: str
    start: float
    end: float


def text_of(words):
    return ''.join(word.text for word in words).strip()


class StreamingTranscript:
    """One inference thread owns hypotheses; caller synchronizes audio snapshots.

    Two consecutive hypotheses must agree before words older than 0.8 seconds
    become stable. Retain two seconds of acoustic context when dropping stable audio;
    trim at completed sentence boundaries and retain at least six seconds.
    A 30-second unresolved window forces progress with a two-second lookahead,
    including on silence. This bounds inference work for long dictation.
    """
    def __init__(self):
        self.offset = 0
        self.committed_end = 0.0
        self.committed = []
        self.previous = []
        self.passes = 0

    def accept(self, words, size, final=False):
        start = self.offset / BYTES_PER_SECOND
        end = start + size / BYTES_PER_SECOND
        words = [Word(w.text, w.start + start, w.end + start) for w in words]
        # Drop only words ending in previously committed audio. The overlap
        # lets the decoder hear boundary consonants without repeating words.
        overlap = 0
        normalize = lambda word: re.sub(r'[^\w]', '', word.text.lower())
        # Timestamps can shift between passes. Match the longest stable suffix
        # in the acoustic overlap before falling back to the time boundary.
        for count in range(min(8, len(self.committed), len(words)), 0, -1):
            suffix = [normalize(w) for w in self.committed[-count:]]
            for index in range(len(words)-count+1):
                stop = index+count
                if (words[stop-1].start < self.committed_end-0.05
                        and abs(words[stop-1].end-self.committed_end) <= 1.0
                        and [normalize(w) for w in words[index:stop]] == suffix):
                    overlap = stop
                    break
            if overlap:
                break
        words = words[overlap:] if overlap else [w for w in words if w.end > self.committed_end + 0.05]
        self.passes += 1
        if final:
            self.committed.extend(words)
            self.previous = []
            return text_of(self.committed), size
        stable = 0
        for old, new in zip(self.previous, words):
            if old.text.strip() != new.text.strip() or abs(old.end-new.end) > 0.8 or new.end > end-0.8:
                break
            stable += 1
        forced = size >= WINDOW_BYTES
        if forced:
            stable = max(stable, sum(w.end <= end-2.0 for w in words))
        self.committed.extend(words[:stable])
        self.previous = words[stable:]
        if stable:
            self.committed_end = words[stable-1].end
            target = min(self.committed_end-OVERLAP_SECONDS, end-6.0)
            boundaries = [w.end for w in self.committed if start < w.end <= target
                          and (forced or w.text.rstrip().endswith(('.', '?', '!')))]
            # Cutting mid-word can trigger Whisper's expensive temperature
            # fallback. Keep complete phrases and a useful acoustic context.
            cut_seconds = max(boundaries, default=start)
        elif forced and not words:
            # VAD found no speech: retain a tail for the next onset.
            cut_seconds = end-2.0
        else:
            cut_seconds = start
        # Even a pathological non-progressing decoder must not grow the window.
        if forced and cut_seconds <= start:
            raise RuntimeError('Recognition could not resolve a bounded audio window')
        cut = min(size, max(0, int((cut_seconds-start)*RATE)*2))
        self.offset += cut
        return text_of(self.committed + self.previous), cut
