# Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT
"""Resident incremental English recognition. Audio is ephemeral; stdout is protocol only."""
import argparse
import base64
import json
import os
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from faster_whisper import WhisperModel
from streaming_asr import StreamingTranscript, Word, STEP_BYTES, WINDOW_BYTES

DEFAULT_INITIAL_PROMPT = 'Augmentor. The user is talking to Augmentor on a Linux desktop.'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', default='small.en')
    parser.add_argument('--compute-type', default='int8')
    parser.add_argument('--revision', default=None)
    parser.add_argument('--max-seconds', type=int, default=600)
    parser.add_argument('--initial-prompt', default=os.environ.get('ASR_INITIAL_PROMPT', DEFAULT_INITIAL_PROMPT))
    args = parser.parse_args()
    if not 1 <= args.max_seconds <= 600:
        parser.error('max-seconds must be 1–600')
    output_lock = threading.Lock()
    condition = threading.Condition()

    def emit(value):
        with output_lock:
            print(json.dumps(value), flush=True)

    model = WhisperModel(args.model, device='cpu', compute_type=args.compute_type, cpu_threads=6, num_workers=1, revision=args.revision)
    executor = ThreadPoolExecutor(max_workers=1)
    state = None
    future = None
    emit({'type': 'ready'})

    def recognize(current):
        transcript = StreamingTranscript()
        decoded_total = 0
        last_text = None
        try:
            while True:
                with condition:
                    condition.wait_for(lambda: current['ended'] or current['cancelled'] or current['total']-decoded_total >= STEP_BYTES)
                    if current['cancelled']:
                        return
                    pcm = bytes(current['samples'][:WINDOW_BYTES])
                    final = current['ended'] and len(current['samples']) <= WINDOW_BYTES
                    decoded_total = transcript.offset + len(pcm)
                started = time.perf_counter()
                if len(pcm) < 3200:
                    words = []
                else:
                    audio = np.frombuffer(pcm, dtype='<i2').astype(np.float32) / 32768
                    segments, _ = model.transcribe(audio, language='en', beam_size=1, vad_filter=True,
                                                  condition_on_previous_text=False, word_timestamps=True,
                                                  initial_prompt=args.initial_prompt or None)
                    words = [Word(w.word, w.start, w.end) for segment in segments for w in segment.words]
                with condition:
                    # Release may arrive during inference: reuse that exact result
                    # when it already covers all audio, rather than decode twice.
                    final = current['ended'] and decoded_total == current['total']
                text, cut = transcript.accept(words, len(pcm), final)
                with condition:
                    if current['cancelled']:
                        return
                    del current['samples'][:cut]
                    end_at = current['end_at']
                metrics = {'passes': transcript.passes, 'decodedThroughSeconds': round(decoded_total/32000, 3),
                           'decodeMs': round((time.perf_counter()-started)*1000, 1), 'windowSeconds': round(len(pcm)/32000, 3)}
                if final:
                    with condition:
                        current['finished'] = True
                    metrics['finalizeMs'] = round((time.perf_counter()-end_at)*1000, 1)
                    emit({'type': 'final', 'utterance': current['id'], 'text': text, **metrics})
                    return
                if text != last_text:
                    emit({'type': 'partial', 'utterance': current['id'], 'text': text, **metrics})
                    last_text = text
        except Exception:
            emit({'type': 'error', 'utterance': current['id'], 'message': 'Recognition failed; no message was submitted.'})
        finally:
            with condition:
                current['samples'].clear()
                current['finished'] = True

    try:
        for line in sys.stdin:
            if len(line) > 100000:
                raise ValueError('Oversized ASR message')
            value = json.loads(line)
            with condition:
                if value['type'] == 'begin':
                    if state is not None and not state['finished']:
                        emit({'type': 'error', 'utterance': value['utterance'], 'message': 'Recognition is still busy. Try again when it finishes.'})
                        continue
                    state = {'id': value['utterance'], 'samples': bytearray(), 'total': 0,
                             'ended': False, 'cancelled': False, 'finished': False, 'end_at': None}
                    future = executor.submit(recognize, state)
                elif state is not None and value.get('utterance') == state['id'] and not state['ended'] and not state['finished']:
                    if value['type'] == 'audio':
                        data = base64.b64decode(value['pcm'], validate=True)
                        if state['total'] + len(data) > args.max_seconds * 32000 or len(data) % 2:
                            raise ValueError('Audio limit exceeded')
                        state['samples'].extend(data)
                        state['total'] += len(data)
                    elif value['type'] == 'end':
                        state['ended'] = True
                        state['end_at'] = time.perf_counter()
                    condition.notify_all()
    finally:
        with condition:
            # EOF without end is cancellation, not permission to submit audio.
            if state is not None and not state['ended']:
                state['cancelled'] = True
            condition.notify_all()
        executor.shutdown(wait=True, cancel_futures=False)


if __name__ == '__main__':
    main()
