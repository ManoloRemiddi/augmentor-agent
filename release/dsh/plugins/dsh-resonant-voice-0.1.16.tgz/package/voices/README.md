<!-- Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT -->
# Synthetic voice assets

The `.breeze` files are saved references for original synthetic voices generated
with Breeze-TTS-2. They are not recordings or clones of real people. Names and
accent descriptions are audition labels, not verified demographic identities.

The application source is MIT. These generated speech references have separate
Breeze model/output terms; the application license does not relicense them.
Consult the [Breeze-TTS-2 model card](https://huggingface.co/BreezeBlue/Breeze-TTS-2)
before redistribution or commercial use. This development deployment records
research/non-commercial restrictions in the main README.

Only the catalogued synthetic `*-preview.wav` audition clips are versioned.
Microphone recordings and model weights are excluded from Git. The preview clips
carry the same upstream output terms as the saved references.
