// Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT
import {spawn} from 'node:child_process';
import {once} from 'node:events';

// Streaming time stretching preserves pitch; changing the device sample rate would not.
export async function* adjustAudio(input,{speed=1,volume=1}={},signal=new AbortController().signal,wav=false){
  if(!wav&&speed===1&&volume===1){yield* input;return;}
  if(!Number.isFinite(speed)||speed<.75||speed>1.5||!Number.isFinite(volume)||volume<0||volume>1)throw Error('Invalid playback settings');
  signal.throwIfAborted();
  const args=['-hide_banner','-loglevel','error',...(wav?[]:['-f','s16le','-ar','24000','-ac','1']),'-probesize','32','-analyzeduration','0','-i','pipe:0','-af',`atempo=${speed},volume=${volume}`,'-ar','24000','-ac','1','-f','s16le','-flush_packets','1','pipe:1'];
  const child=spawn('ffmpeg',args,{stdio:['pipe','pipe','pipe']});
  let error=null;
  child.on('error',()=>{error=Error('Playback speed needs ffmpeg installed on the speech host.');});
  child.stdin.on('error',()=>{});child.stderr.resume();
  const exited=new Promise(resolve=>child.once('close',resolve));
  const cancel=()=>child.kill('SIGTERM');signal.addEventListener('abort',cancel,{once:true});
  const writing=(async()=>{
    try{for await(const pcm of input){signal.throwIfAborted();if(child.stdin.destroyed)throw Error('Audio processor closed its input');if(!child.stdin.write(pcm))await once(child.stdin,'drain');}child.stdin.end();}
    catch(e){error=e;child.kill('SIGTERM');}
  })();
  try{
    let tail=Buffer.alloc(0);
    for await(const chunk of child.stdout){const b=Buffer.concat([tail,chunk]),n=b.length&~1;tail=b.subarray(n);if(n)yield b.subarray(0,n);}
    const code=await exited;await writing;signal.throwIfAborted();
    if(error)throw error;if(code!==0||tail.length)throw Error('Could not process speech speed or volume.');
  }finally{signal.removeEventListener('abort',cancel);child.kill('SIGTERM');}
}
