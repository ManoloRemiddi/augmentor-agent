// Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT
import {setTimeout as delay} from 'node:timers/promises';
import {performance} from 'node:perf_hooks';
import {createServer} from 'node:http';
import {randomBytes,randomUUID} from 'node:crypto';
import {WebSocketServer} from 'ws';
import {authorized,jsonBody} from './config.js';
import {BreezeHTTP,WhisperWorker} from './adapters.js';
import {VoicePreferences} from './preferences.js';
import {SpeechText} from './text.js';
import {deliverySettings} from './delivery.js';

export function createVoiceService(config,{tts=new BreezeHTTP(config.tts),workerFactory=(...args)=>new WhisperWorker(...args)}={}) {
  const preferences=new VoicePreferences(config);
  const maxSeconds=Math.min(config.maxUtteranceSeconds??600,600);
  const maxBytes=maxSeconds*32000;
  let owner=null,closing=false;const tickets=new Map(), eventCounts={};
  const send=(o,value)=>{if(o?.ws.readyState===1)o.ws.send(JSON.stringify(value));};
  function invalidate(o){
    o.responseSettings=null;o.epoch=(o.epoch+1)>>>0;o.abort?.abort();o.queue=[];o.pendingText=0;o.playUntil=0;
    o.parser=new SpeechText(text=>enqueue(o,text));
    send(o,{type:'clear',generation:o.epoch});
  }
  function fail(o,message,recoverable=false){invalidate(o);send(o,{type:'error',message,recoverable});}
  function enqueue(o,text){
    if(o.muted||o.suppressed||owner!==o)return;
    if(o.pendingText+text.length>32768){o.suppressed=true;fail(o,'Speech fell behind. Read the remaining answer in chat.');return;}
    o.queue.push({text,settings:{...(o.responseSettings??o.speechSettings??preferences.settings(o.profile))}});o.pendingText+=text.length;void drain(o);
  }
  async function drain(o){
    if(o.draining)return;o.draining=true;
    try{
      while(owner===o&&o.queue.length){
        const {text,settings}=o.queue.shift();o.pendingText-=text.length;
        const generation=o.epoch,abort=new AbortController();o.abort=abort;let first=true;
        try{
          send(o,{type:'speaking',generation,text,delivery:{emotion:settings.emotion??'neutral',speed:settings.speed??1,laughter:settings.laughter??'none'}});
          for await(const pcm of tts.speak(text,abort.signal,settings)){
            if(owner!==o||o.epoch!==generation||abort.signal.aborted)break;
            // Bound audio ahead of playback, including across synthesis requests.
            // Socket bufferedAmount alone does not measure the client's audio queue.
            for(let offset=0;offset<pcm.length;offset+=4800){
              const part=pcm.subarray(offset,offset+4800);
              const wait=Math.max(0,(o.playUntil||0)-performance.now()-500);
              if(wait)await delay(wait,undefined,{signal:abort.signal});
              if(owner!==o||o.epoch!==generation||abort.signal.aborted)break;
              if(o.ws.bufferedAmount+part.length>384000)throw Error('Audio connection fell behind');
              const header=Buffer.alloc(8);header.writeUInt32LE(generation,0);header.writeUInt32LE(o.sequence++,4);
              o.ws.send(Buffer.concat([header,part]));
              o.playUntil=Math.max(o.playUntil||0,performance.now())+part.length/48;
            }
            if(first){first=false;send(o,{type:'timing',stage:'first-pcm',generation,at:Date.now(),elapsedMs:o.endInputAt===undefined?undefined:performance.now()-o.endInputAt});}
          }
        }catch(error){if(!abort.signal.aborted&&owner===o){o.suppressed=true;fail(o,error.message,true);}}
        finally{if(o.abort===abort)o.abort=null;}
      }
    }finally{o.draining=false;if(owner===o)send(o,{type:'speech-idle',generation:o.epoch});}
  }
  function finishInput(o,automatic=false){
    if(!o.capturing)return;
    o.capturing=false;o.autoEnded=automatic;clearTimeout(o.captureTimer);
    o.endInputAt=performance.now();
    o.worker.send({type:'end',utterance:o.utterance});
    if(automatic)send(o,{type:'recording-ended',reason:'limit',maxUtteranceSeconds:maxSeconds});
    send(o,{type:'recognizing'});
  }
  function closeOwner(o){if(!o)return;clearTimeout(o.captureTimer);invalidate(o);o.worker?.close();if(owner===o)owner=null;}
  const server=createServer(async(req,res)=>{
    const answer=(status,data)=>{res.writeHead(status,{'content-type':'application/json','cache-control':'no-store'});res.end(JSON.stringify(data));};
    if(req.headers.host!==`127.0.0.1:${config.port}`||req.headers.origin){answer(403,{error:'Local bridge only'});return;}
    if(req.method==='GET'&&req.url==='/health'){answer(200,{protocol:'resonant-voice/1',active:!!owner});return;}
    if(req.method!=='POST'||!authorized(req.headers['x-resonant-token'],config.token)){answer(403,{error:'Authentication required'});return;}
    try{
      const p=await jsonBody(req,65536);
      if(req.url==='/internal/preferences'){
        if(p.values&&owner?.capturing)throw Error('Finish recording before changing voice settings.');
        answer(200,p.values?preferences.save(p.values,p.profile):preferences.get(p.profile));return;
      }
      if(req.url==='/internal/preview'){
        if(owner?.capturing)throw Error('Finish recording before previewing a voice.');
        const abort=new AbortController();res.on('close',()=>abort.abort());
        const pcm=await preferences.preview(p,abort.signal,p.profile);
        res.writeHead(200,{'content-type':'audio/pcm','cache-control':'no-store'});res.end(pcm);return;
      }
      if(req.url==='/internal/status'){
        answer(200,{active:!!owner,events:eventCounts,owner:owner?{sessionId:owner.sessionId,surfaceSpeech:owner.surfaceSpeech,capturing:owner.capturing,asrReady:owner.worker?.ready,awaitingTurn:owner.awaitingTurn,suppressed:owner.suppressed,stream:owner.stream,queued:owner.queue.length}:null});return;
      }
      if(req.url==='/internal/ticket'){
        if(!['linux','browser'].includes(p.surface)||!/^[-a-zA-Z0-9_]{1,128}$/.test(p.sessionId))throw Error('Invalid session');
        for(const [key,value] of tickets)if(value.expires<Date.now())tickets.delete(key);
        if(tickets.size>=64)throw Error('Too many pending connections');
        const ticket=randomBytes(32).toString('hex');tickets.set(ticket,{...p,expires:Date.now()+15000});
        answer(200,{protocol:'resonant-voice/1',url:`ws://127.0.0.1:${config.port}/voice`,ticket,sessionId:p.sessionId});return;
      }
      if(req.url==='/internal/event'){
        eventCounts[p.type]=(eventCounts[p.type]||0)+1;
        const o=owner;
        if(o?.sessionId===p.sessionId&&(!o.surfaceSpeech||p.type==='cancel')){
          if(p.type==='user-turn'){
            const matches=p.requestId===o.utterance||p.requestId==='resonant-voice:'+o.utterance;
            if(!o.capturing&&(!o.awaitingTurn||matches)){
              if(!o.awaitingTurn)invalidate(o);
              o.requestId=p.requestId;o.responseIds=new Set();o.awaitingTurn=false;o.armed=true;o.suppressed=false;o.speechSettings={...preferences.settings(o.profile)};
            }
          }
          else if(p.type==='turn-complete'){
            if(o.armed&&!o.suppressed&&!o.capturing&&!o.awaitingTurn&&p.requestId===o.requestId){
              send(o,{type:'turn-complete',generation:o.epoch,requestId:o.requestId});
              if(!o.draining&&!o.queue.length)send(o,{type:'speech-idle',generation:o.epoch});
            }
          }
          else if(p.type==='response'){
            if(!config.expressiveSpeech||!o.armed||o.suppressed||o.capturing||p.requestId!==o.requestId||typeof p.responseId!=='string'||typeof p.text!=='string'||p.text.length>4000||o.responseIds?.has(p.responseId)){answer(200,{ok:true,ignored:true});return;}
            const segments=p.segments??[{text:p.text,speech:p.speech}];
            if(!Array.isArray(segments)||segments.length<1||segments.length>8||segments.some(s=>!s||typeof s.text!=='string'||!s.text.trim()||s.text.length>(p.segments?1000:4000))||segments.map(s=>s.text).join('\n\n')!==p.text){answer(400,{error:'Invalid voice segments'});return;}
            o.responseIds??=new Set();o.responseIds.add(p.responseId);
            for(const segment of segments){
              o.responseSettings=deliverySettings(o.speechSettings??preferences.settings(o.profile),segment.speech);
              const parts=[];const parser=new SpeechText(text=>parts.push(text));parser.push(segment.text);parser.end();
              if(parts.length)enqueue(o,parts.join(' '));
            }
            o.responseSettings=null;
          }
          else if(p.type==='start'){
            // Assistant tool continuations share playback; do not chop the preceding clause.
            o.parser=new SpeechText(text=>enqueue(o,text));
            o.suppressed=o.capturing||o.awaitingTurn||!o.armed;o.stream=p.stream;
          }
          else if(p.type==='cancel'){o.suppressed=true;o.armed=false;invalidate(o);}
          else if(p.stream===o.stream&&!o.suppressed){
            if(p.type==='text')o.parser.push(String(p.text||''));
            if(p.type==='end')o.parser.end();
          }
        }
        answer(200,{ok:true});return;
      }
      answer(404,{error:'Unknown operation'});
    }catch(error){answer(400,{error:error.message});}
  });
  const wss=new WebSocketServer({noServer:true,maxPayload:65536,perMessageDeflate:false});
  server.on('upgrade',(req,socket,head)=>{
    const origin=req.headers.origin;
    if(closing||req.url!=='/voice'||req.headers.host!==`127.0.0.1:${config.port}`||origin&&!/^chrome-extension:\/\/[a-p]{32}$/.test(origin)){socket.destroy();return;}
    wss.handleUpgrade(req,socket,head,ws=>wss.emit('connection',ws,req));
  });
  wss.on('connection',(ws,req)=>{
    let o=null,authenticating=false;
    const timer=setTimeout(()=>ws.close(1008,'Authentication timeout'),5000);
    ws.on('message',async(data,binary)=>{
      try{
        if(!o){
          if(authenticating||binary)throw Error('Authenticate first');
          const p=JSON.parse(data.toString()),ticket=tickets.get(p.ticket);tickets.delete(p.ticket);
          if(p.type!=='auth'||!ticket||ticket.expires<Date.now())throw Error('Expired ticket');
          if(req.headers.origin&&ticket.surface!=='browser')throw Error('Surface mismatch');
          if(owner)throw Error('Voice is already in use in another window');
          const profile=preferences.profileName(p.profile??'main');
          preferences.settings(profile);
          authenticating=true;
          o={...ticket,profile,ws,epoch:0,sequence:0,queue:[],pendingText:0,muted:false,suppressed:true,capturing:false,bytes:0,surfaceSpeech:p.textSource==='surface',lastReply:-1};owner=o;
          clearTimeout(timer);invalidate(o);
          // Claim ownership before asynchronous health checks to prevent a second claimant.
          await tts.health();if(owner!==o||ws.readyState!==1)return;
          o.worker=workerFactory({...config.asr,maxUtteranceSeconds:maxSeconds},event=>{
            if(owner!==o)return;
            if(event.type==='ready')send(o,{type:'ready',protocol:'resonant-voice/1',maxUtteranceSeconds:maxSeconds,input:{sampleRate:16000,channels:1,format:'s16le'},output:{sampleRate:24000,channels:1,format:'s16le'},mode:'push-to-talk',asr:'faster-whisper CPU (incremental recognition)'});
            else if(event.utterance===o.utterance){
              if(event.type==='partial'){
                send(o,{type:'transcript-partial',text:event.text,requestId:event.utterance,sessionId:o.sessionId});
                send(o,{type:'timing',stage:'asr-progress',passes:event.passes,decodedThroughSeconds:event.decodedThroughSeconds,decodeMs:event.decodeMs});
              }else if(event.type==='final'){
                send(o,{type:'timing',stage:'asr-final',elapsedMs:performance.now()-o.endInputAt,passes:event.passes,decodedThroughSeconds:event.decodedThroughSeconds,decodeMs:event.decodeMs});
                if(event.text?.trim())send(o,{type:'transcript',text:event.text.trim(),requestId:event.utterance,sessionId:o.sessionId});
                else send(o,{type:'empty-transcript'});
              }
              else if(event.type==='error')send(o,{type:'error',message:event.message});
            }
          },message=>{fail(o,message);ws.close(1011,'ASR unavailable');});
          return;
        }
        if(binary){
          if(data.length%2)throw Error('Invalid PCM alignment');
          // A few in-flight packets can arrive after the automatic finish notification.
          if(o.autoEnded&&!o.capturing)return;
          if(!o.capturing||!o.worker?.ready)throw Error('Microphone is not armed');
          const part=data.subarray(0,Math.max(0,maxBytes-o.bytes));
          if(part.length){o.bytes+=part.length;o.worker.send({type:'audio',utterance:o.utterance,pcm:part.toString('base64')});}
          if(o.bytes>=maxBytes)finishInput(o,true);
          return;
        }
        const p=JSON.parse(data.toString());
        if(p.type==='reply'){
          if(!o.surfaceSpeech||!Number.isSafeInteger(p.seq)||p.seq<0||typeof p.text!=='string'||p.text.length>32768)throw Error('Invalid surface reply');
          if(p.seq<=o.lastReply)return;
          o.lastReply=p.seq;
          if(o.capturing)return;
          eventCounts['surface-reply']=(eventCounts['surface-reply']||0)+1;
          o.suppressed=false;o.awaitingTurn=false;o.parser.push(p.text);o.parser.end();
        }else if(p.type==='begin'){
          if(!o.worker?.ready||o.capturing)throw Error('Recognition is not ready');
          invalidate(o);o.suppressed=true;o.awaitingTurn=true;o.capturing=true;o.autoEnded=false;o.armed=false;o.bytes=0;o.utterance=randomUUID();
          o.worker.send({type:'begin',utterance:o.utterance});send(o,{type:'listening',requestId:o.utterance});
          o.captureTimer=setTimeout(()=>{if(owner===o&&o.capturing){try{finishInput(o,true);}catch{fail(o,'Could not finish recording');ws.close(1011,'ASR unavailable');}}},maxSeconds*1000);
        }else if(p.type==='end'){
          if(!o.capturing&&!o.autoEnded)throw Error('No active utterance');
          finishInput(o);
        }else if(p.type==='mute'){o.muted=!!p.value;if(o.muted)invalidate(o);}
        else if(p.type==='interrupt'){o.suppressed=true;o.armed=false;invalidate(o);}
        else if(p.type==='playback-drained'){
          // Advisory acknowledgment, never authority to restart the microphone.
          if(Number.isSafeInteger(p.generation)&&p.generation===o.epoch)o.drainedGeneration=p.generation;
        }
        else throw Error('Unknown control');
      }catch(error){send(o||{ws},{type:'error',message:error.message});ws.close(1008,'Voice request failed');}
    });
    ws.on('close',()=>{clearTimeout(timer);closeOwner(o);});ws.on('error',()=>{});
  });
  return {server,listen:()=>new Promise(resolve=>server.listen(config.port,'127.0.0.1',resolve)),close:async()=>{
    closing=true;closeOwner(owner);for(const ws of wss.clients)ws.terminate();wss.close();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));
  }};
}
