// Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT
import {readFileSync, mkdirSync, writeFileSync, existsSync, statSync} from 'node:fs';
import {homedir} from 'node:os';
import {join} from 'node:path';
import {randomBytes, createHash, timingSafeEqual} from 'node:crypto';
export const configHome = () => process.env.RESONANT_VOICE_HOME || join(process.env.XDG_CONFIG_HOME || join(homedir(), '.config'), 'resonant-voice');
export const defaults = {protocol:'resonant-voice/1', port:8877, tts:{adapter:'breeze-http', url:'http://127.0.0.1:8878', voiceId:'resonant-clara', seed:83, instruction:'Speak naturally and conversationally in English.',speed:1,volume:1}, asr:{adapter:'faster-whisper', python:'python3', model:'small.en', revision:'d1d751a5f8271d482d14ca55d9e2deeebbae577f', device:'cpu', computeType:'int8'}, maxUtteranceSeconds:600,voiceLibrary:join(homedir(),'.local/share/resonant-voice/voices')};
export function initialize() {
  const dir=configHome(); mkdirSync(dir,{recursive:true,mode:0o700});
  if(!existsSync(join(dir,'token')))writeFileSync(join(dir,'token'),randomBytes(32).toString('hex'),{mode:0o600,flag:'wx'});
  if(!existsSync(join(dir,'config.json')))writeFileSync(join(dir,'config.json'),JSON.stringify(defaults,null,2)+'\n',{mode:0o600,flag:'wx'});
  return dir;
}
export function settings() {
  const dir=configHome(), token=readFileSync(join(dir,'token'),'utf8').trim();
  if(!/^[a-f0-9]{64}$/.test(token) || (statSync(join(dir,'token')).mode & 0o077))throw Error('Voice token must be private (chmod 600) and contain 64 hex characters.');
  const raw=JSON.parse(readFileSync(join(dir,'config.json'),'utf8'));
  const config={...defaults,...raw,tts:{...defaults.tts,...raw.tts},asr:{...defaults.asr,...raw.asr},token};
  if(!Number.isInteger(config.port)||config.port<1024||config.port>65535)throw Error('Invalid voice port');
  if(!Number.isInteger(config.maxUtteranceSeconds)||config.maxUtteranceSeconds<1||config.maxUtteranceSeconds>600)throw Error('Recording limit must be 1–600 seconds');
  const url=new URL(config.tts.url);
  if(url.protocol!=='http:'||url.hostname!=='127.0.0.1'||url.username||url.password)throw Error('Breeze must use an explicit loopback HTTP endpoint');
  if(config.tts.adapter!=='breeze-http'||config.asr.adapter!=='faster-whisper')throw Error('Unknown speech adapter');
  if(config.asr.device!=='cpu')throw Error('This baseline ASR adapter is CPU-only; GPU placement needs qualification.');
  if(config.asr.initialPrompt!==undefined&&typeof config.asr.initialPrompt!=='string')throw Error('ASR initialPrompt must be a plain string.');
  config.settingsPath=join(dir,'config.json');
  return config;
}
export function authorized(value,token) {
  const hash=v=>createHash('sha256').update(String(v||'')).digest();
  return timingSafeEqual(hash(value),hash(token));
}
export async function jsonBody(req,limit=16384) {
  let size=0;const chunks=[];
  for await(const chunk of req){size+=chunk.length;if(size>limit)throw Error('Request too large');chunks.push(chunk);}
  return JSON.parse(Buffer.concat(chunks).toString());
}
