// Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT
import {readFileSync} from 'node:fs';
import {join} from 'node:path';
import {homedir} from 'node:os';
import {randomUUID} from 'node:crypto';
import {settings,authorized,jsonBody} from './config.js';
import {responseTool} from './delivery.js';
import {ResponseGate,voiceTools} from './response-gate.js';
export const name='resonant-voice';
export const inject=['agents','webServer','sessionQuery','tools'];
export function apply(ctx){
  const config=settings();const base=`http://127.0.0.1:${config.port}`;
  const productToken=readFileSync(join(process.env.DSH_HOME||join(homedir(),'.dsh'),'augmentor-product-token'),'utf8').trim();
  const streams=new Map(),leases=new Map();let closed=false;
  if(config.expressiveSpeech){
    ctx.effect(()=>ctx.tools.register(responseTool(id=>leases.get(id))));
    ctx.on('tools/result',(exec,result)=>{
      if(voiceTools.has(exec.name)&&!result.isError&&exec.agent&&!exec.signal.aborted)event(exec.agent,{type:'response',responseId:exec.callId,...result.value});
    });
  }
  async function post(path,p){
    const res=await fetch(base+path,{method:'POST',headers:{'content-type':'application/json','x-resonant-token':config.token},body:JSON.stringify(p),signal:AbortSignal.timeout(3000),redirect:'error'});
    if(!res.ok)throw Error('Resonant Voice service is unavailable');return res.json();
  }
  // Ordered and bounded per-session transport, never await speech in the agent loop.
  function event(agent,p){
    if(closed||!leases.has(agent.id))return;
    const state=leases.get(agent.id);
    if(state.expires<Date.now()){leases.delete(agent.id);return;}
    if(state.pending>128){state.disabled=true;clearTimeout(state.timer);leases.delete(agent.id);void post('/internal/event',{sessionId:agent.id,type:'cancel'}).catch(()=>{});return;}
    state.pending++;
    state.chain=state.chain.then(()=>state.disabled?undefined:post('/internal/event',{sessionId:agent.id,...p})).catch(()=>{state.disabled=true;clearTimeout(state.timer);leases.delete(agent.id);}).finally(()=>state.pending--);
  }
  function flush(agent){const state=leases.get(agent.id);if(!state?.text)return;clearTimeout(state.timer);state.timer=null;const text=state.text;state.text='';event(agent,{type:'text',stream:streams.get(agent.id),text});}
  ctx.on('agent/assistant-stream',({agent,frame})=>{
    const state=leases.get(agent.id);
    if(frame.type==='start'){
      const stream=randomUUID();streams.set(agent.id,stream);
      if(state){clearTimeout(state.timer);state.text='';state.gate=new ResponseGate(config.expressiveSpeech&&state.voiceStyle);}
      event(agent,{type:'start',stream});
    }else if(frame.type==='chunk'&&state){
      const text=state.gate?.push(frame.chunk)||'';
      if(text){state.text=(state.text||'')+text;if(state.text.length>16000)flush(agent);else if(!state.timer)state.timer=setTimeout(()=>{state.timer=null;flush(agent);},25);}
    }else if(frame.type==='end'){
      const committed=frame.outcome?.kind==='committed'&&frame.outcome.eventType==='assistant/message';
      if(state){state.text=(state.text||'')+(state.gate?.finish(committed)||'');state.gate=null;}
      if(committed)flush(agent);else if(state){clearTimeout(state.timer);state.text='';}
      event(agent,{type:committed?'end':'cancel',stream:streams.get(agent.id)});streams.delete(agent.id);
    }
  });
  ctx.on('agent/inbox/claimed',({agent,message})=>{if(message.source?.kind==='user'){const lease=leases.get(agent.id);if(lease)lease.requestId=message.source.rpcId;event(agent,{type:'user-turn',requestId:message.source.rpcId});}});
  // Idle is emitted after the driver drains/closes/checkpoints turns. A stream
  // end or turn-stopping hook can precede more tool work and is not terminal.
  ctx.on('agent/status',({agent,status})=>{
    const lease=leases.get(agent.id);
    if(status==='idle'&&lease?.requestId){flush(agent);event(agent,{type:'turn-complete',requestId:lease.requestId});}
  });
  ctx.on('agent/pre-step',async ({agent,messages},next)=>{
    const decision=await next();
    if(decision.kind==='reject')return decision;
    const human=messages.filter(m=>m.source?.kind==='user').at(-1);
    const lease=leases.get(agent.id);
    if(!human||!lease||lease.disabled||lease.expires<Date.now()||!['augmentor-linux-product','augmentor-browser-product'].includes(agent.session.header.agentPreset))return decision;
    const voice=String(human.source.rpcId||'').startsWith('resonant-voice:');
    if(!voice&&!lease.voiceStyle)return decision;
    lease.voiceStyle=voice;
    const text=voice
      ? 'Resonant Voice: this user message was spoken. For this request and its tool continuations, answer like a conversational partner: lead with the answer, normally one to three short sentences and no more than about 60 words. Do not enumerate every capability, read URLs, or use headings and tables. Give one useful point, then leave space for the user to follow up. Expand only when clearly requested; if a garbled transcript seems to request a very long answer, ask one short clarification. For substantial tasks, do the requested work but keep the spoken status and result concise. Do not sacrifice necessary accuracy or change permissions, tools, model, or reasoning policy. These style instructions apply only to this spoken request.'
      : 'Resonant Voice is not the input mode for this request. Resume the usual text-answer style and follow the current user request; prior voice-only brevity instructions do not apply.';
    return {...decision,messages:[...decision.messages,{id:randomUUID(),role:'user',content:[{type:'text',text:text+(voice&&config.expressiveSpeech?' The previous fixed voice demonstration has been removed. Ignore earlier instructions to use it. Respond to what the user actually says, in your own words, through resonant_voice_reply with segments. Use one coherent passage normally; use multiple passages with different speech metadata only when their meaning or the user request calls for it. Choose emotion and pace for each passage naturally, with no prescribed order, stock sentences, labels, or automatic tour of emotions. Do not explain the voice controls unless asked. Supported delivery directions are neutral, warm, sad, excited, playful (amused), and calm. Match your words to their intended emotion; respond playfully when the conversation calls for humor, with no obligation to make every reply cheerful. Normally keep speedMultiplier at 1; changes are limited to 0.97–1.03 and excitement does not require faster speech. For an actual brief laugh, set optional speech.laughter to before or after on the appropriate passage; usually omit it. Choose a laugh when sharing amusement or when the user requests laughter, not indiscriminately or during distress. Keep laugh tags, asterisks and written hahahas out of text: the adapter generates the vocal event from metadata. Other vocal effects and exact word emphasis are unsupported. Do not claim you verified the audible emotion; only the listener can assess the performance. Metadata is separate from the words. Call the reply tool alone after completing any requested work. If unavailable, answer normally.':'')}],source:{kind:'plugin',plugin:'resonant-voice'}}]};
  });
  ctx.on('agent/disposed',({agent})=>{event(agent,{type:'cancel'});streams.delete(agent.id);leases.delete(agent.id);});
  ctx.effect(()=>ctx.webServer.register({kind:'exact',path:'/api/resonant-voice',handler:async(req,res)=>{
    const answer=(code,data)=>{res.writeHead(code,{'content-type':'application/json','cache-control':'no-store'});res.end(JSON.stringify(data));};
    try{
      const host=new URL('http://'+req.headers.host);
      if(!['127.0.0.1','[::1]'].includes(host.hostname)||req.headers.origin&&req.headers.origin!==host.origin||req.method!=='POST'||!authorized(req.headers['x-augmentor-product-token'],productToken))throw Error('Authorized local request required');
      const p=await jsonBody(req);
      if(!['linux','browser'].includes(p.surface)||typeof p.sessionId!=='string')throw Error('Invalid voice session');
      const observation=await ctx.sessionQuery.observeSession(p.sessionId);
      try{if(observation.header.agentPreset!==`augmentor-${p.surface}-product`||observation.header.origin==='subagent')throw Error('Conversation belongs to another role');}
      finally{observation[Symbol.dispose]();}
      const ticket=await post('/internal/ticket',{sessionId:p.sessionId,surface:p.surface});
      leases.set(p.sessionId,{expires:Date.now()+12*3600000,pending:0,chain:Promise.resolve()});
      answer(200,{ok:true,...ticket});
    }catch(error){answer(400,{ok:false,error:error.message});}
  }}));
  ctx.on('dispose',()=>{closed=true;for(const [sessionId,state] of leases){state.disabled=true;clearTimeout(state.timer);void post('/internal/event',{sessionId,type:'cancel'}).catch(()=>{});}streams.clear();leases.clear();});
}
