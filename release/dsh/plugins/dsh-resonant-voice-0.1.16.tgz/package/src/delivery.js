// Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT
export const emotions=['warm','sad','excited','playful','calm','neutral'];
export function delivery(value){
  const emotion=emotions.includes(value?.emotion)?value.emotion:'neutral';
  const hint=value?.speedMultiplier;
  // Older calls remain valid, but automatic delivery never accelerates by 15%.
  const speedMultiplier=Number.isFinite(hint)&&hint>=.85&&hint<=1.15?Math.min(1.03,Math.max(.97,hint)):1;
  const laughter=['before','after'].includes(value?.laughter)?value.laughter:undefined;
  return {emotion,speedMultiplier,...(laughter?{laughter}:{})};
}
export function deliverySettings(base={},value){
  const speech=delivery(value);
  const directions={warm:'Speak warmly and kindly.',sad:'Speak with sadness and tenderness, subdued energy and gentle falling intonation.',excited:'Speak with joy and enthusiasm in your intonation, at an unhurried conversational pace.',playful:'Speak with light amusement and a smile in your voice, at a relaxed conversational pace. Do not rush or shout.',calm:'Speak calmly and reassuringly.',neutral:'Speak naturally and conversationally.'};
  return {...base,emotion:speech.emotion,laughter:speech.laughter??'none',speed:Math.min(1.5,Math.max(.75,(base.speed??1)*speech.speedMultiplier)),instruction:`${directions[speech.emotion]} Use the supplied reference voice and preserve its identity. Speak in English.`};
}
const speechSchema={type:'object',additionalProperties:false,required:['emotion','speedMultiplier'],properties:{emotion:{type:'string',enum:emotions},speedMultiplier:{type:'number',description:'Relative to user speed: 0.97–1.03; normally 1. Express excitement through intonation, not rapid speech.'},laughter:{type:'string',enum:['none','before','after'],description:'Optional brief real laugh before or after this passage, only when the meaning or user request calls for shared amusement. Usually none. Keep all laugh tags out of text.'}}};
export function responseTool(getLease){
  return {
    name:'resonant_voice_reply',
    description:'Deliver your own conversational answer with per-passage voice direction. Usually use one segment; add segments only when the meaning calls for a change in delivery. Each segment contains your actual reply words and speech metadata. Call alone after completing requested work. No prerecorded wording, fixed sequence, or audible emotion labels. This ends the turn.',
    parameters:{type:'object',additionalProperties:false,required:['segments'],properties:{segments:{type:'array',description:'1–8 coherent passages; up to 1000 characters each and 4000 total.',items:{type:'object',additionalProperties:false,required:['text','speech'],properties:{text:{type:'string',description:'Your own reply text, exactly as it should be spoken.'},speech:speechSchema}}}}},
    output:{schema:{type:'object',additionalProperties:true},render:(_args,value)=>[{type:'text',text:value.text}],presentationMeta:(_args,value)=>({resonantVoice:{version:1,text:value.text,segments:value.segments}})},
    async execute(args,exec){
      exec.signal.throwIfAborted();
      const lease=getLease(exec.agent?.id);
      if(!lease?.voiceStyle||!lease.requestId||lease.disabled||lease.expires<Date.now())throw Error('Structured voice replies require an active spoken request.');
      // Accept earlier text/speech calls during transition; advertise only segments.
      const segments=args?.segments??(typeof args?.text==='string'?[{text:args.text,speech:args.speech}]:null);
      if(!Array.isArray(segments)||segments.length<1||segments.length>8||segments.some(s=>!s||typeof s.text!=='string'||!s.text.trim()||s.text.length>(args.segments?1000:4000)))throw Error('Use 1–8 non-empty conversational passages.');
      const text=segments.map(s=>s.text).join('\n\n');
      if(text.length>4000)throw Error('Keep the complete spoken reply within 4000 characters.');
      const value={text,segments:segments.map(s=>({text:s.text,speech:delivery(s.speech)})),requestId:lease.requestId};
      exec.concludeTurn();return value;
    }
  };
}
