// Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT
import {adjustAudio} from './audio.js';
import {setTimeout as delay} from 'node:timers/promises';
import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {fileURLToPath} from 'node:url';
export class BreezeHTTP {
  constructor(config){this.config=config;}
  async health(){
    const res=await fetch(this.config.url+'/health',{signal:AbortSignal.timeout(3000),redirect:'error'});
    if(!res.ok)throw Error('Breeze is not ready');
    const data=await res.json();if(data.status!=='ok'||data.sample_rate!==24000)throw Error('Incompatible Breeze runtime');
    return {adapter:'breeze-http',sampleRate:24000,streamingAudio:true,streamingText:false};
  }
  async *speak(text,signal,options=this.config){
    yield* adjustAudio(this.rawSpeech(text,signal,options),options,signal);
  }
  async *rawSpeech(text,signal,options){
    // The vocal event is explicit metadata, never guessed from words/punctuation.
    const laughter=['before','after'].includes(options.laughter)?options.laughter:null;
    const synthesisText=laughter==='before'?`(laugh) ${text}`:laughter==='after'?`${text} (laugh)`:text;
    const form=new FormData();form.set('text',synthesisText);
    // Breeze recommends CFG 2–3 for vocal events. Use the lower bound only
    // for requested laughter; ordinary passages retain the fast CFG=1 path.
    form.set('cfg_scale',laughter?'2.0':'1.0');form.set('instruction',options.instruction);form.set('seed',String(options.seed ?? 42));
    if(options.voiceId)form.set('voice_id',options.voiceId);
    const requestSignal=AbortSignal.any([signal,AbortSignal.timeout(120000)]);
    const busyDeadline=Date.now()+10000;let res;
    while(true){
      requestSignal.throwIfAborted();
      res=await fetch(this.config.url+'/v1/audio/speech',{method:'POST',body:form,signal:requestSignal,redirect:'error'});
      if(res.status!==409||Date.now()>=busyDeadline)break;
      // A cancelled synthesis can still be releasing Breeze's generation lock.
      // Retry only an explicit busy rejection, before any audio was accepted.
      await res.body?.cancel();await delay(150,undefined,{signal:requestSignal});
    }
    if(!res.ok)throw Error(`Breeze returned HTTP ${res.status}`);
    const type=res.headers.get('content-type')||'';
    if(!/audio\/(pcm|raw)|application\/octet-stream/.test(type))throw Error('Breeze did not return raw PCM');
    let tail=Buffer.alloc(0);
    for await(const chunk of res.body){const data=Buffer.concat([tail,chunk]);const n=data.length&~1;tail=data.subarray(n);if(n)yield data.subarray(0,n);}
    if(tail.length)throw Error('Incomplete PCM sample');
  }
}
export class WhisperWorker {
  constructor(config,onEvent,onFailure){
    this.process=spawn(config.python,[fileURLToPath(new URL('../workers/asr.py',import.meta.url)),'--model',config.model,'--compute-type',config.computeType,'--max-seconds',String(config.maxUtteranceSeconds??600),...(config.revision?['--revision',config.revision]:[]),...(typeof config.initialPrompt==='string'?['--initial-prompt',config.initialPrompt]:[])],{stdio:['pipe','pipe','pipe']});
    this.ready=false;this.closed=false;
    const lines=createInterface({input:this.process.stdout});
    lines.on('line',line=>{try{const event=JSON.parse(line);if(event.type==='ready')this.ready=true;onEvent(event);}catch{onFailure('Invalid ASR worker response');}});
    // Audio and transcripts never go to logs. Keep only a bounded diagnostic tail.
    this.diagnostic='';this.process.stderr.on('data',chunk=>{this.diagnostic=(this.diagnostic+chunk.toString()).slice(-2048);});
    this.process.on('error',()=>onFailure('Could not start the ASR worker. Check the configured Python environment.'));
    this.process.on('exit',()=>{if(!this.closed)onFailure('ASR worker exited. Check the model and Python dependencies.');});
    this.process.stdin.on('error',()=>{});
  }
  send(value){if(this.process.stdin.destroyed||this.process.stdin.writableLength>4*1024*1024)throw Error('ASR input is unavailable or overloaded');this.process.stdin.write(JSON.stringify(value)+'\n');}
  close(){this.closed=true;this.process.kill('SIGTERM');}
}
