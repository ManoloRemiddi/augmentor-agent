// Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT
import {readFileSync,writeFileSync,renameSync,unlinkSync} from 'node:fs';
import {join,basename} from 'node:path';
import {randomUUID} from 'node:crypto';
import {adjustAudio} from './audio.js';

export class VoicePreferences {
  constructor(config){this.config=config;}
  library(){
    if(!this.config.voiceLibrary)return [];
    try{
      const data=JSON.parse(readFileSync(join(this.config.voiceLibrary,'library.json'),'utf8'));
      return data.voices.filter(v=>/^resonant-[a-z0-9-]+$/.test(v.id)&&typeof v.name==='string'&&typeof v.sample==='string'&&basename(v.sample)===v.sample);
    }catch(error){if(error.code==='ENOENT')return [];throw error;}
  }
  profileName(profile='main'){
    if(typeof profile!=='string'||!/^([a-z][a-z0-9-]{0,31})$/.test(profile))throw Error('Invalid voice profile');
    return profile;
  }
  persist(update){
    if(!this.config.settingsPath)throw Error('Persistent voice settings are unavailable.');
    const stored=JSON.parse(readFileSync(this.config.settingsPath,'utf8'));update(stored);
    const temporary=this.config.settingsPath+'.'+randomUUID()+'.tmp';
    try{writeFileSync(temporary,JSON.stringify(stored,null,2)+'\n',{mode:0o600,flag:'wx'});renameSync(temporary,this.config.settingsPath);}
    finally{try{unlinkSync(temporary);}catch{}}
  }
  settings(profile='main'){
    this.profileName(profile);
    if(profile==='main')return this.config.tts??{};
    if(!Object.hasOwn(this.config.voiceProfiles??{},profile)){
      const cloned={...(this.config.tts??{})};
      this.persist(stored=>{stored.voiceProfiles={...stored.voiceProfiles,[profile]:cloned};});
      this.config.voiceProfiles={...this.config.voiceProfiles,[profile]:cloned};
    }
    return this.config.voiceProfiles[profile];
  }
  get(profile='main'){
    const settings=this.settings(profile);
    const voices=this.library().map(({id,name,description})=>({id,name,description}));
    if(settings.voiceId&&!voices.some(v=>v.id===settings.voiceId))voices.unshift({id:settings.voiceId,name:'Original voice',description:'Your previous voice'});
    return {voices,values:{voiceId:settings.voiceId,speed:settings.speed??1,volume:settings.volume??1},profile};
  }
  validate(values,profile='main'){
    if(!values||typeof values.voiceId!=='string'||!this.get(profile).voices.some(v=>v.id===values.voiceId))throw Error('Choose an available voice.');
    if(typeof values.speed!=='number'||!Number.isFinite(values.speed)||values.speed<.75||values.speed>1.5)throw Error('Speed must be between 0.75× and 1.50×.');
    if(typeof values.volume!=='number'||!Number.isFinite(values.volume)||values.volume<0||values.volume>1)throw Error('Volume must be between 0 and 100%.');
  }
  save(values,profile='main'){
    this.validate(values,profile);
    const settings=this.settings(profile),voice=this.library().find(v=>v.id===values.voiceId);
    const changes={voiceId:values.voiceId,speed:values.speed,volume:values.volume,...(voice?{seed:voice.seed,instruction:voice.instruction}:{})};
    this.persist(stored=>{
      if(profile==='main')stored.tts={...stored.tts,...changes};
      else stored.voiceProfiles={...stored.voiceProfiles,[profile]:{...settings,...changes}};
    });
    Object.assign(settings,changes);
    return this.get(profile);
  }
  async preview(values,signal,profile='main'){
    this.validate(values,profile);
    const voice=this.library().find(v=>v.id===values.voiceId);
    if(!voice)throw Error('No saved preview is available for this voice.');
    const wav=readFileSync(join(this.config.voiceLibrary,voice.sample));
    if(wav.length>4*1024*1024)throw Error('Voice preview is too large.');
    const chunks=[];
    for await(const pcm of adjustAudio([wav],values,signal,true))chunks.push(pcm);
    return Buffer.concat(chunks);
  }
}
