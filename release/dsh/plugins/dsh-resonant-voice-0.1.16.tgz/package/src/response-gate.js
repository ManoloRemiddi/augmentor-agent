// Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT
export const voiceTools=new Set(['resonant_voice_reply']);
// A structured attempt has exactly one speech source. Ordinary prose is held
// until we know whether the model also chose a structured reply tool.
export class ResponseGate {
  constructor(structured){this.structured=structured;this.text='';this.tool=false;this.overflow=false;}
  push(chunk){
    if(voiceTools.has(chunk.name)||chunk.type==='block-end'&&chunk.block?.type==='tool-call'&&voiceTools.has(chunk.block.name))this.tool=true;
    if(chunk.type!=='text-delta')return '';
    if(!this.structured)return chunk.text;
    if(this.text.length+chunk.text.length<=32768)this.text+=chunk.text;else this.overflow=true;
    return '';
  }
  finish(committed){return committed&&this.structured&&!this.tool&&!this.overflow?this.text:'';}
}
