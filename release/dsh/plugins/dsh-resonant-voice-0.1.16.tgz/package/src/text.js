// Copyright © 2026 Manolo Remiddi · SPDX-License-Identifier: MIT
// Line-aware buffering prevents a split Markdown fence from leaking code to speech.
export class SpeechText {
  constructor(emit){this.emit=emit;this.pending='';this.fence=false;this.html=false;}
  push(text){
    this.pending+=text;
    if(this.pending.length>32768)throw Error('Spoken text segment exceeded its limit');
    let end;
    while((end=this.pending.indexOf('\n'))>=0){const line=this.pending.slice(0,end);this.pending=this.pending.slice(end+1);this.line(line,true);}
    // Do not release a line with unclosed markup, URL or code delimiters.
    if(!this.fence&&!this.html&&!/[`~<>\[\]]/.test(this.pending)){
      const match=this.pending.match(/^(.{24,}?[.!?;](?:\s|$))/s);
      if(match){this.pending=this.pending.slice(match[0].length);this.line(match[0]);}
      else if(this.pending.length>180){const cut=this.pending.lastIndexOf(' ',180);if(cut>=80){this.line(this.pending.slice(0,cut));this.pending=this.pending.slice(cut+1);}}
    }
  }
  line(text,newline=false){
    if(/^\s*(`{3,}|~{3,})/.test(text)){this.fence=!this.fence;return;}
    if(this.fence)return;
    if(/<(script|style|pre)\b/i.test(text))this.html=true;
    if(this.html){if(/<\/(script|style|pre)>/i.test(text))this.html=false;return;}
    const clean=text.replace(/`[^`]*`/g,'').replace(/!\[[^\]]*\]\([^)]*\)/g,'').replace(/\[([^\]]+)\]\([^)]*\)/g,'$1').replace(/https?:\/\/\S+/g,'').replace(/<[^>]*>/g,'').replace(/^[#>*\s-]+/,'').replace(/[*_]/g,'').trim();
    if(clean&&(!/[`<>]/.test(clean)))this.emit(clean);
  }
  end(){if(this.pending)this.line(this.pending);this.pending='';}
}
